import React, { useState, useMemo, useCallback, useRef, useEffect } from "react";
import * as Backend from "./backendBridge";
import {
  PawPrint, Heart, Home, Calendar, ShoppingCart, User, Stethoscope, Scissors,
  Shield, Search, Plus, Trash2, Pencil, X, Menu, Sun, Moon, LogOut, Check,
  Star, MapPin, Phone, Mail, Upload, Bell, Filter, ChevronRight, ChevronDown,
  Dog, Cat, Bird, Fish, Rabbit, Building2, ClipboardList, FileText, Clock,
  Syringe, Activity, Camera, ArrowRight, CheckCircle2, AlertCircle, Sparkles,
  LayoutGrid, Package, Users, ClipboardCheck, MessageSquare, BadgeCheck,
  ChevronLeft, Eye, EyeOff, Info
} from "lucide-react";

/* ============================================================================
   FURSHIELD — Pet Care Full-Stack Frontend
   "Every Paw/Wing Deserves a Shield of Love"
   Design language: rounded "Fredoka" display type + "Inter" body type,
   layered paw/blob motifs, dual light/dark theme via CSS custom properties.
============================================================================ */

/* Real, freely-licensed photos (Pexels — free to use, no attribution required).
   Used for hero imagery, species thumbnails and dashboard banners. */
const PEXELS = (id, w = 1200) => `https://images.pexels.com/photos/${id}/pexels-photo-${id}.jpeg?auto=compress&cs=tinysrgb&w=${w}`;
const PHOTOS = {
  dogDark: PEXELS(16876005),      // golden retriever, dramatic dark backdrop
  dogLight: PEXELS(9419449),      // golden retriever, sunny grass
  dogAutumn: PEXELS(2759564),     // golden retriever, warm forest light
  dogGroup: PEXELS(17186345),     // golden retrievers, studio
  cat1: PEXELS(14355838),         // tabby cat portrait
  cat2: PEXELS(19040485),         // cat peeking from box
  cat3: PEXELS(19820189),         // cream british shorthair
  cat4: PEXELS(16772359),         // ginger tabby
  cat5: PEXELS(8287652),          // blue-eyed cat
  rabbit1: PEXELS(4588071),       // white rabbit, purple backdrop
  rabbit2: PEXELS(19943347),      // lop rabbit, dark backdrop
  bird1: PEXELS(18452241),        // rainbow lorikeet
  bird2: PEXELS(16147932),        // lovebirds
  vetDog: PEXELS(6234610),        // veterinarian examining a dog
};
const SPECIES_PHOTO = {
  Dog: [PHOTOS.dogLight, PHOTOS.dogDark, PHOTOS.dogAutumn, PHOTOS.dogGroup],
  Cat: [PHOTOS.cat1, PHOTOS.cat2, PHOTOS.cat3, PHOTOS.cat4, PHOTOS.cat5],
  Rabbit: [PHOTOS.rabbit1, PHOTOS.rabbit2],
  Bird: [PHOTOS.bird1, PHOTOS.bird2],
  Fish: [],
};
const speciesPhoto = (species, seed = 0) => {
  const arr = SPECIES_PHOTO[species];
  if (!arr || arr.length === 0) return null;
  return arr[seed % arr.length];
};

const SPECIES_ICON = { Dog, Cat, Bird, Fish, Rabbit };
const speciesIcon = (s) => SPECIES_ICON[s] || PawPrint;

const uid = (() => { let n = 1000; return () => ++n; })();

/* Small helper for staggered entrance animation across grids/lists */
function AnimIn({ i = 0, children, className = "", as = "div", style = {}, ...rest }) {
  const Tag = as;
  return React.createElement(Tag, { className: `fs-anim-in ${className}`, style: { animationDelay: `${Math.min(i, 10) * 55}ms`, ...style }, ...rest }, children);
}
const fmtDate = (d) => new Date(d).toLocaleDateString(undefined, { day: "numeric", month: "short", year: "numeric" });
const fmtMoney = (n) => `$${Number(n).toFixed(2)}`;

/* ---------------------------------- Seed Data ---------------------------------- */

const SEED_ACCOUNTS = [
  { id: 1, role: "owner", name: "Ayesha Khan", email: "owner@demo.com", password: "demo123", phone: "0300-1234567", address: "Block 4, Gulshan, Karachi" },
  { id: 2, role: "vet", name: "Dr. Sara Ahmed", email: "vet@demo.com", password: "demo123", phone: "0321-9876543", address: "DHA Phase 5, Karachi", specialization: "Small Animal Medicine", experience: "8 years", bio: "Passionate about preventive care and gentle handling.", slots: ["Mon 10:00 AM", "Mon 2:00 PM", "Wed 11:00 AM", "Fri 4:00 PM"] },
  { id: 3, role: "shelter", name: "Hope Paws Shelter", email: "shelter@demo.com", password: "demo123", phone: "021-111222333", address: "North Nazimabad, Karachi" },
  { id: 4, role: "vet", name: "Dr. Bilal Farooq", email: "bilal.vet@demo.com", password: "demo123", phone: "0333-1122334", address: "Clifton, Karachi", specialization: "Exotic & Avian Care", experience: "5 years", bio: "Specialist in birds, reptiles and small mammals.", slots: ["Tue 9:00 AM", "Thu 1:00 PM", "Sat 10:00 AM"] },
];

const SEED_PETS = [
  { id: 101, ownerId: 1, name: "Luna", species: "Dog", breed: "Golden Retriever", age: "2 yrs", gender: "Female", notes: "Loves belly rubs, mild pollen allergy.", images: [] },
  { id: 102, ownerId: 1, name: "Milo", species: "Cat", breed: "Tabby", age: "1 yr", gender: "Male", notes: "Indoor cat, on a grain-free diet.", images: [] },
];

const SEED_RECORDS = [
  { id: 201, petId: 101, type: "Vaccination", title: "Rabies Booster", date: "2026-03-12", notes: "Annual booster, no reaction.", vetId: 2 },
  { id: 202, petId: 101, type: "Treatment", title: "Ear Infection", date: "2026-05-02", notes: "Prescribed ear drops for 7 days.", vetId: 2 },
  { id: 203, petId: 102, type: "Allergy", title: "Chicken sensitivity", date: "2026-01-20", notes: "Switched to grain-free, fish-based diet.", vetId: null },
  { id: 204, petId: 101, type: "Milestone", title: "First grooming session", date: "2025-11-05", notes: "Went very well, very calm.", vetId: null },
];

const SEED_APPTS = [
  { id: 301, petId: 101, ownerId: 1, vetId: 2, date: "2026-09-20", time: "10:00 AM", status: "Confirmed", reason: "Annual checkup" },
  { id: 302, petId: 102, ownerId: 1, vetId: 2, date: "2026-09-25", time: "2:00 PM", status: "Pending", reason: "Skin irritation" },
];

const SEED_PRODUCTS = [
  { id: 401, name: "Grain-Free Chicken Kibble 3kg", category: "Food", price: 24.99, stock: 40, desc: "Premium grain-free formula for sensitive stomachs.", icon: "🥘" },
  { id: 402, name: "Salmon & Rice Wet Food (12-pack)", category: "Food", price: 18.5, stock: 60, desc: "Complete balanced nutrition, vet-recommended.", icon: "🐟" },
  { id: 403, name: "Deshedding Slicker Brush", category: "Grooming", price: 9.99, stock: 75, desc: "Reduces shedding by up to 90%.", icon: "🪮" },
  { id: 404, name: "Oatmeal Calming Shampoo", category: "Grooming", price: 12.0, stock: 30, desc: "Soothes sensitive, itchy skin.", icon: "🧴" },
  { id: 405, name: "Rope & Squeak Toy Bundle", category: "Toys", price: 14.99, stock: 50, desc: "Set of 3 durable chew + squeak toys.", icon: "🧸" },
  { id: 406, name: "Feather Wand Cat Teaser", category: "Toys", price: 6.5, stock: 90, desc: "Interactive play for indoor cats.", icon: "🪶" },
  { id: 407, name: "Joint Care Chewables (60ct)", category: "Health", price: 21.0, stock: 25, desc: "Glucosamine + chondroitin support.", icon: "💊" },
  { id: 408, name: "Digital Ear Thermometer", category: "Health", price: 16.75, stock: 20, desc: "Fast, accurate readings at home.", icon: "🌡️" },
  { id: 409, name: "Clicker Training Kit", category: "Training", price: 8.99, stock: 45, desc: "Beginner-friendly positive reinforcement kit.", icon: "🔔" },
  { id: 410, name: "Puppy Pads (50-pack)", category: "Training", price: 15.25, stock: 55, desc: "Super-absorbent, leak-proof pads.", icon: "📦" },
];

const SEED_LISTINGS = [
  { id: 501, shelterId: 3, petName: "Bella", species: "Dog", breed: "Labrador Mix", age: "8 months", health: "Vaccinated, dewormed", status: "Available", image: "🐕", careLog: [{ id: 1, type: "Feeding", note: "Fed twice daily, good appetite", date: "2026-09-10" }] },
  { id: 502, shelterId: 3, petName: "Whiskers", species: "Cat", breed: "Domestic Shorthair", age: "1.5 yrs", health: "Neutered, FVRCP vaccinated", status: "Available", image: "🐈", careLog: [] },
  { id: 503, shelterId: 3, petName: "Coco", species: "Rabbit", breed: "Dutch Rabbit", age: "6 months", health: "Healthy, litter-trained", status: "Pending", image: "🐇", careLog: [] },
  { id: 504, shelterId: 3, petName: "Sunny", species: "Bird", breed: "Cockatiel", age: "1 yr", health: "Full check-up completed", status: "Available", image: "🦜", careLog: [] },
];

const SEED_QUERIES = [
  { id: 601, listingId: 501, name: "Fatima Ali", email: "fatima@example.com", message: "Hi, is Bella good with kids? We have a 6-year-old.", status: "New" },
  { id: 602, listingId: 502, name: "Omar Sheikh", email: "omar@example.com", message: "I'd love to meet Whiskers this weekend, is that possible?", status: "Responded" },
];

const CARE_ARTICLES = [
  { id: 1, cat: "Feeding", title: "Building a Balanced Feeding Schedule", desc: "How often, how much, and what to watch for across life stages." },
  { id: 2, cat: "Hygiene", title: "Bath Time Without the Drama", desc: "Step-by-step grooming routines pets actually tolerate." },
  { id: 3, cat: "Exercise", title: "Daily Movement for Every Breed", desc: "Matching activity levels to your pet's energy and age." },
  { id: 4, cat: "Feeding", title: "Reading Pet Food Labels Like a Pro", desc: "What those ingredient lists are really telling you." },
  { id: 5, cat: "Hygiene", title: "Dental Care Basics", desc: "Simple habits that prevent costly vet visits later." },
  { id: 6, cat: "Exercise", title: "Indoor Enrichment for Rainy Days", desc: "Keep minds and bodies active without leaving home." },
];

const NAV_LINKS = [
  { id: "home", label: "Home" },
  { id: "services", label: "Services" },
  { id: "shop-public", label: "Shop" },
  { id: "adopt-public", label: "Adopt" },
  { id: "about", label: "About" },
  { id: "contact", label: "Contact" },
];

/* ============================================================================ */

export default function FurShieldApp() {
  const [theme, setTheme] = useState("light");
  const [ripple, setRipple] = useState(null);
  const THEME_BG = { light: "#FBFAF6", dark: "#0B0A14" };
  const THEME_GLOW = { light: "rgba(124,77,255,.55)", dark: "rgba(177,140,255,.6)" };
  const toggleTheme = useCallback((e) => {
    const rect = e?.currentTarget?.getBoundingClientRect?.();
    const x = rect ? rect.left + rect.width / 2 : window.innerWidth - 40;
    const y = rect ? rect.top + rect.height / 2 : 40;
    const next = theme === "light" ? "dark" : "light";
    const size = Math.max(window.innerWidth, window.innerHeight) * 2.3;
    setRipple({ x, y, size, color: THEME_BG[next], glow: THEME_GLOW[next], key: Date.now() });
    setTimeout(() => setTheme(next), 120);
    setTimeout(() => setRipple(null), 750);
  }, [theme]);
  const [view, setView] = useState("home");
  const [authMode, setAuthMode] = useState("login");
  const [authRole, setAuthRole] = useState("owner");
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const [toast, setToast] = useState(null);

  const [accounts, setAccounts] = useState(SEED_ACCOUNTS);
  const [user, setUser] = useState(null);

  const [pets, setPets] = useState(SEED_PETS);
  const [records, setRecords] = useState(SEED_RECORDS);
  const [appts, setAppts] = useState(SEED_APPTS);
  const [products, setProductsState] = useState(SEED_PRODUCTS);
  const [cart, setCart] = useState([]);
  const [orders, setOrders] = useState([]);
  const [listings, setListings] = useState(SEED_LISTINGS);
  const [queries, setQueries] = useState(SEED_QUERIES);
  const [reviews, setReviews] = useState([
    { id: 1, target: "Dr. Sara Ahmed", rating: 5, comment: "So gentle with Luna, highly recommend!", author: "Ayesha K." },
    { id: 2, target: "Hope Paws Shelter", rating: 5, comment: "Adoption process was smooth and caring.", author: "Omar S." },
  ]);

  const [dashTab, setDashTab] = useState("overview");

  const notify = useCallback((msg, kind = "success") => {
    setToast({ msg, kind, key: Date.now() });
    setTimeout(() => setToast(null), 2800);
  }, []);

  const goto = (v, tab) => {
    setView(v);
    if (tab) setDashTab(tab);
    setMobileNavOpen(false);
    window.scrollTo?.({ top: 0, behavior: "smooth" });
  };

  const [backendReady, setBackendReady] = useState(false);

  useEffect(() => {
    let alive = true;
    Backend.getCurrentUser().then(async (sessionUser) => {
      if (!alive) return;
      if (sessionUser) {
        setUser(sessionUser);
        setView("dashboard");
        setDashTab("overview");
        const data = await Backend.loadAppData(sessionUser);
        if (!alive) return;
        setAccounts(data.accounts || []);
        setPets(data.pets || []);
        setRecords(data.records || []);
        setAppts(data.appts || []);
        setProductsState(data.products || []);
        setCart(data.cart || []);
        setOrders(data.orders || []);
        setListings(data.listings || []);
        setQueries(data.queries || []);
        setReviews(data.reviews || []);
      } else {
        const data = await Backend.loadAppData(null);
        if (!alive) return;
        setProductsState(data.products || []);
        setListings(data.listings || []);
        setReviews(data.reviews || []);
      }
      setBackendReady(true);
    }).catch(() => { if (alive) setBackendReady(false); });
    return () => { alive = false; };
  }, []);

  useEffect(() => {
    if (!user) return;
    return Backend.onAuthStateChange(async (nextUser) => {
      setUser(nextUser);
      if (!nextUser) { setView("home"); return; }
      const data = await Backend.loadAppData(nextUser);
      setAccounts(data.accounts || []);
      setPets(data.pets || []);
      setRecords(data.records || []);
      setAppts(data.appts || []);
      setProductsState(data.products || []);
      setCart(data.cart || []);
      setOrders(data.orders || []);
      setListings(data.listings || []);
      setQueries(data.queries || []);
      setReviews(data.reviews || []);
    });
  }, [user?.id]);

  const doLogin = async (email, password, role) => {
    try {
      const acc = await Backend.signIn(email, password, role);
      setUser(acc);
      setDashTab("overview");
      setView("dashboard");
      notify(`Welcome back, ${acc.name.split(" ")[0]}!`);
      return true;
    } catch (e) { notify(e.message || "Invalid credentials for this role.", "error"); return false; }
  };

  const doRegister = async (data) => {
    try {
      const acc = await Backend.signUp(data);
      if (!acc) { notify("Account created. Please check your email to confirm your account."); return true; }
      setUser(acc);
      setDashTab("overview");
      setView("dashboard");
      notify(`Account created — welcome to FurShield, ${acc.name.split(" ")[0]}!`);
      return true;
    } catch (e) { notify(e.message || "Unable to create account.", "error"); return false; }
  };

  const doLogout = async () => {
    try { await Backend.signOut(); } catch {}
    setUser(null);
    setView("home");
    notify("You've been logged out.");
  };

  const cartCount = cart.reduce((s, c) => s + c.qty, 0);
  const cartTotal = cart.reduce((s, c) => {
    const p = products.find(p => p.id === c.productId);
    return s + (p ? p.price * c.qty : 0);
  }, 0);

  const addToCart = async (productId) => {
    if (!user) return;
    try {
      await Backend.apiAddToCart(user.id, productId);
      setCart((await Backend.getCart(user.id)).map(Backend.mapCart));
      notify("Added to cart.");
    } catch (e) { notify(e.message || "Unable to add to cart.", "error"); }
  };
  const setCartQty = async (productId, qty) => {
    if (!user) return;
    try {
      await Backend.apiSetCartQty(user.id, productId, qty);
      setCart((await Backend.getCart(user.id)).map(Backend.mapCart));
    } catch (e) { notify(e.message || "Unable to update cart.", "error"); }
  };
  const removeFromCart = async (productId) => {
    if (!user) return;
    try {
      await Backend.apiRemoveFromCart(user.id, productId);
      setCart(prev => prev.filter(c => c.productId !== productId));
    } catch (e) { notify(e.message || "Unable to remove item.", "error"); }
  };

  const checkout = async () => {
    if (!user || cart.length === 0) return;
    try {
      const rows = cart.map(c => ({ product_id: c.productId, qty: c.qty, products: products.find(p => p.id === c.productId) }));
      const order = await Backend.apiCheckout(user.id, rows);
      setOrders(prev => [Backend.mapOrder({ ...order, order_items: rows.map(c => ({ product_id: c.product_id, qty: c.qty, unit_price: c.products.price })) }), ...prev]);
      setCart([]);
      notify("Order placed! (No payment/delivery in this build, per project scope.)");
    } catch (e) { notify(e.message || "Unable to place order.", "error"); }
  };

  const ctx = {
    theme, setTheme, toggleTheme, view, goto, authMode, setAuthMode, authRole, setAuthRole,
    mobileNavOpen, setMobileNavOpen, notify, accounts, user, doLogin, doRegister, doLogout,
    pets, setPets, records, setRecords, appts, setAppts, products, cart, setCart, addToCart,
    setCartQty, removeFromCart, cartTotal, cartCount, checkout, orders, listings, setListings,
    queries, setQueries, reviews, setReviews, dashTab, setDashTab,
  };

  return (
    <div data-theme={theme} className="fs-root">
      <GlobalStyle />
      {ripple && (
        <>
          <div className="fs-theme-ripple" style={{ left: ripple.x - ripple.size / 2, top: ripple.y - ripple.size / 2, width: ripple.size, height: ripple.size, background: `radial-gradient(circle, ${ripple.color} 60%, ${ripple.color} 100%)` }} />
          <div className="fs-theme-glow" style={{ left: ripple.x - 140, top: ripple.y - 140, width: 280, height: 280, background: `radial-gradient(circle, rgba(255,255,255,.9) 0%, ${ripple.glow} 40%, transparent 72%)` }} />
        </>
      )}
      {toast && <Toast toast={toast} />}
      {view !== "dashboard" && <PublicNavbar ctx={ctx} />}
      <main key={view} className="fs-page-enter">
        {view === "home" && <HomePage ctx={ctx} />}
        {view === "services" && <ServicesPage ctx={ctx} />}
        {view === "shop-public" && <ShopPublicPage ctx={ctx} />}
        {view === "adopt-public" && <AdoptPublicPage ctx={ctx} />}
        {view === "about" && <AboutPage ctx={ctx} />}
        {view === "contact" && <ContactPage ctx={ctx} />}
        {view === "auth" && <AuthPage ctx={ctx} />}
        {view === "dashboard" && user && <DashboardShell ctx={ctx} />}
      </main>
      {view !== "dashboard" && <Footer ctx={ctx} />}
    </div>
  );
}

/* ============================================================================
   GLOBAL STYLE — CSS variables drive both themes; Tailwind handles layout.
============================================================================ */
function GlobalStyle() {
  return (
    <style>{`
      @import url('https://fonts.googleapis.com/css2?family=Fredoka:wght@400;500;600;700&family=Inter:wght@400;500;600;700;800&display=swap');

      .fs-root[data-theme="light"]{
        --bg:#FBFAF6; --bg-soft:#F4F1FC; --surface:#FFFFFF; --surface-2:#F6F3FE;
        --text:#211C34; --muted:#6B6483; --border:#E9E4F7;
        --p1:#7C4DFF; --p1-soft:#EFE7FF; --p2:#FF6B9D; --p2-soft:#FFE7F0;
        --p3:#FFB020; --p3-soft:#FFF3DE; --p4:#17B897; --p4-soft:#DFF7F0;
        --grad: linear-gradient(120deg,#7C4DFF 0%, #FF6B9D 60%, #FFB020 100%);
        --shadow: 0 10px 30px -12px rgba(80,60,150,0.18);
        --shadow-sm: 0 4px 14px -6px rgba(80,60,150,0.15);
        --hero-bg: radial-gradient(circle at 15% 20%, #EFE7FF 0%, transparent 45%), radial-gradient(circle at 85% 15%, #FFE7F0 0%, transparent 40%), #FBFAF6;
        --navbg: rgba(251,250,246,0.85);
      }
      .fs-root[data-theme="dark"]{
        --bg:#0B0A14; --bg-soft:#120F20; --surface:#15121F; --surface-2:#1B1730;
        --text:#F3F0FF; --muted:#A79FC4; --border:rgba(255,255,255,0.09);
        --p1:#B18CFF; --p1-soft:rgba(177,140,255,0.14); --p2:#FF7FB0; --p2-soft:rgba(255,127,176,0.14);
        --p3:#FFC94B; --p3-soft:rgba(255,201,75,0.14); --p4:#3FE0C0; --p4-soft:rgba(63,224,192,0.14);
        --grad: linear-gradient(120deg,#B18CFF 0%, #FF7FB0 60%, #FFC94B 100%);
        --shadow: 0 20px 60px -20px rgba(0,0,0,0.6), 0 0 40px -10px rgba(177,140,255,0.18);
        --shadow-sm: 0 8px 24px -10px rgba(0,0,0,0.5);
        --hero-bg: radial-gradient(circle at 15% 15%, rgba(177,140,255,0.16) 0%, transparent 45%), radial-gradient(circle at 85% 10%, rgba(255,127,176,0.14) 0%, transparent 40%), #0B0A14;
        --navbg: rgba(11,10,20,0.85);
      }
      .fs-root{ background:var(--bg); color:var(--text); font-family:'Inter',sans-serif; min-height:100vh; transition:background .25s ease,color .25s ease; }
      .fs-display{ font-family:'Fredoka',sans-serif; }
      .fs-grad-text{ background:var(--grad); -webkit-background-clip:text; background-clip:text; color:transparent; }
      .fs-card{ background:var(--surface); border:1px solid var(--border); border-radius:20px; box-shadow:var(--shadow-sm); }
      .fs-surface2{ background:var(--surface-2); }
      .fs-border{ border-color:var(--border); }
      .fs-muted{ color:var(--muted); }
      .fs-btn-primary{ background:var(--grad); color:#fff; border-radius:999px; font-weight:600; transition:transform .18s ease, box-shadow .18s ease; box-shadow:var(--shadow-sm); }
      .fs-btn-primary:hover{ transform:translateY(-2px); box-shadow:var(--shadow); }
      .fs-btn-outline{ background:transparent; color:var(--text); border:1.5px solid var(--border); border-radius:999px; font-weight:600; transition: border-color .18s ease, background .18s ease; }
      .fs-btn-outline:hover{ border-color:var(--p1); background:var(--p1-soft); }
      .fs-chip{ border-radius:999px; font-weight:600; font-size:0.78rem; padding:5px 12px; }
      .fs-input{ background:var(--surface); border:1.5px solid var(--border); border-radius:14px; color:var(--text); padding:11px 14px; width:100%; font-size:0.95rem; }
      .fs-input:focus{ outline:none; border-color:var(--p1); box-shadow:0 0 0 3px var(--p1-soft); }
      .fs-scroll::-webkit-scrollbar{ width:8px; height:8px; }
      .fs-scroll::-webkit-scrollbar-thumb{ background:var(--border); border-radius:8px; }
      .fs-pulse-ring{ animation: fsRing 2.8s ease-in-out infinite; }
      @keyframes fsRing{ 0%,100%{ transform:scale(1); opacity:.5; } 50%{ transform:scale(1.12); opacity:.15; } }
      @keyframes fsFloat{ 0%,100%{ transform:translateY(0px) rotate(0deg);} 50%{ transform:translateY(-10px) rotate(2deg);} }
      .fs-float{ animation: fsFloat 5s ease-in-out infinite; }
      .fs-float-delay{ animation: fsFloat 6s ease-in-out infinite; animation-delay: 1.2s; }
      @media (prefers-reduced-motion: reduce){ .fs-float,.fs-float-delay,.fs-pulse-ring{ animation:none; } }
      .fs-focusable:focus-visible{ outline: 2.5px solid var(--p1); outline-offset:2px; }
      .fs-side-link{ border-radius:14px; transition: background .15s ease, color .15s ease; }
      .fs-side-link:hover{ background:var(--surface-2); }
      .fs-side-link.active{ background:var(--grad); color:#fff; }
      .fs-side-link.active svg{ color:#fff; }

      /* ---------- Motion system ---------- */
      @keyframes fsFadeUp{ from{ opacity:0; transform:translateY(18px) scale(.985); } to{ opacity:1; transform:translateY(0) scale(1); } }
      @keyframes fsFadeIn{ from{ opacity:0; } to{ opacity:1; } }
      @keyframes fsPopIn{ from{ opacity:0; transform:scale(.85); } to{ opacity:1; transform:scale(1); } }
      @keyframes fsSlideRight{ from{ opacity:0; transform:translateX(-16px); } to{ opacity:1; transform:translateX(0); } }
      @keyframes fsSpinSlow{ from{ transform:rotate(0deg);} to{ transform:rotate(360deg);} }
      @keyframes fsBob{ 0%,100%{ transform:translateY(0);} 50%{ transform:translateY(-6px);} }
      @keyframes fsWag{ 0%,100%{ transform:rotate(0deg);} 25%{ transform:rotate(-8deg);} 75%{ transform:rotate(8deg);} }
      @keyframes fsShimmer{ 0%{ background-position:-200% 0;} 100%{ background-position:200% 0;} }
      @keyframes fsRipple{ 0%{ transform:scale(0); opacity:1; } 70%{ opacity:1; } 100%{ transform:scale(1); opacity:0; } }
      @keyframes fsGlowPulse{ 0%{ opacity:0; transform:scale(.6); } 35%{ opacity:1; } 100%{ opacity:0; transform:scale(1.4); } }

      .fs-anim-in{ animation: fsFadeUp .55s cubic-bezier(.22,.68,0,1.01) both; }
      .fs-anim-pop{ animation: fsPopIn .4s cubic-bezier(.34,1.56,.64,1) both; }
      .fs-anim-fade{ animation: fsFadeIn .5s ease both; }
      .fs-anim-slide{ animation: fsSlideRight .45s cubic-bezier(.22,.68,0,1.01) both; }
      .fs-page-enter{ animation: fsFadeUp .45s cubic-bezier(.22,.68,0,1.01) both; }
      .fs-bob{ animation: fsBob 3.2s ease-in-out infinite; }
      .fs-wag{ display:inline-block; transform-origin:70% 70%; animation: fsWag 1.8s ease-in-out infinite; }
      .fs-spin-slow{ animation: fsSpinSlow 12s linear infinite; }
      .fs-logo-mark svg{ transition: transform .5s cubic-bezier(.34,1.56,.64,1); }
      .fs-logo-mark:hover svg{ animation: fsWag .6s ease-in-out; }

      .fs-card{ transition: transform .25s cubic-bezier(.22,.68,0,1.01), box-shadow .25s ease, border-color .25s ease, background .25s ease; }
      .fs-root[data-theme="dark"] .fs-card{ backdrop-filter: blur(6px); }
      .fs-root[data-theme="dark"] .fs-card-hover:hover{ box-shadow: var(--shadow), 0 0 0 1px var(--p1) inset; }
      .fs-root[data-theme="dark"] .fs-grad-text{ filter: drop-shadow(0 0 18px rgba(177,140,255,.35)); }
      .fs-card-hover:hover{ transform: translateY(-6px); box-shadow: var(--shadow); border-color: var(--p1); }
      .fs-icon-pop{ transition: transform .3s cubic-bezier(.34,1.56,.64,1); }
      .fs-card-hover:hover .fs-icon-pop{ transform: scale(1.12) rotate(-4deg); }
      .fs-tap{ transition: transform .12s ease; }
      .fs-tap:active{ transform: scale(.94); }
      button{ transition: transform .18s cubic-bezier(.34,1.56,.64,1), box-shadow .18s ease, background .18s ease, border-color .18s ease, opacity .18s ease; }
      button:active{ transform: scale(.96); }
      .fs-chip{ transition: all .2s ease; }
      .fs-input{ transition: border-color .2s ease, box-shadow .2s ease, transform .15s ease; }
      .fs-input:focus{ transform: translateY(-1px); }

      .fs-theme-ripple{ position:fixed; z-index:9999; pointer-events:none; border-radius:50%; animation: fsRipple .7s cubic-bezier(.22,.68,0,1.01) forwards; }
      .fs-theme-glow{ position:fixed; z-index:10000; pointer-events:none; border-radius:50%; animation: fsGlowPulse .7s ease-out forwards; }

      .fs-skel{ background: linear-gradient(90deg, var(--surface-2) 25%, var(--border) 50%, var(--surface-2) 75%); background-size:200% 100%; animation: fsShimmer 1.6s ease-in-out infinite; }

      .fs-modal-backdrop{ animation: fsFadeIn .25s ease both; }
      .fs-modal-panel{ animation: fsPopIn .3s cubic-bezier(.34,1.56,.64,1) both; }

      @media (prefers-reduced-motion: reduce){
        .fs-anim-in,.fs-anim-pop,.fs-anim-fade,.fs-anim-slide,.fs-page-enter,.fs-bob,.fs-wag,.fs-spin-slow,.fs-theme-ripple{ animation:none !important; }
        .fs-card-hover:hover{ transform:none; }
      }
    `}</style>
  );
}

function Toast({ toast }) {
  const bad = toast.kind === "error";
  return (
    <div key={toast.key} className="fs-anim-slide fixed top-5 right-5 z-[999] fs-card px-4 py-3 flex items-center gap-2 max-w-xs"
      style={{ borderColor: bad ? "var(--p2)" : "var(--p4)" }}>
      {bad ? <AlertCircle size={18} style={{ color: "var(--p2)" }} /> : <CheckCircle2 size={18} style={{ color: "var(--p4)" }} />}
      <span className="text-sm font-medium">{toast.msg}</span>
    </div>
  );
}

/* ============================================================================
   NAVBAR
============================================================================ */
function Logo({ size = 34 }) {
  return (
    <div className="flex items-center gap-2 select-none">
      <div className="fs-logo-mark rounded-2xl flex items-center justify-center" style={{ width: size, height: size, background: "var(--grad)" }}>
        <PawPrint size={size * 0.58} color="#fff" strokeWidth={2.4} />
      </div>
      <div className="leading-none">
        <div className="fs-display font-semibold text-lg" style={{ letterSpacing: "-0.01em" }}>FurShield</div>
        <div className="text-[10px] fs-muted -mt-0.5">Care · Shield · Love</div>
      </div>
    </div>
  );
}

function ThemeToggle({ theme, toggleTheme }) {
  return (
    <button
      aria-label="Toggle theme"
      onClick={toggleTheme}
      className="fs-focusable fs-tap w-10 h-10 rounded-full flex items-center justify-center fs-border border overflow-hidden"
      style={{ background: "var(--surface-2)" }}
    >
      <span key={theme} className="fs-anim-pop flex items-center justify-center">
        {theme === "light" ? <Moon size={17} /> : <Sun size={17} className="fs-spin-slow" />}
      </span>
    </button>
  );
}

function PublicNavbar({ ctx }) {
  const { view, goto, theme, toggleTheme, mobileNavOpen, setMobileNavOpen, user } = ctx;
  return (
    <header className="sticky top-0 z-50 backdrop-blur-md border-b fs-border" style={{ background: "var(--navbg)" }}>
      <div className="max-w-7xl mx-auto px-5 md:px-8 h-[72px] flex items-center justify-between">
        <button className="fs-focusable" onClick={() => goto("home")}><Logo /></button>
        <nav className="hidden lg:flex items-center gap-1">
          {NAV_LINKS.map(l => (
            <button key={l.id} onClick={() => goto(l.id)}
              className={`fs-focusable px-4 py-2 rounded-full text-sm font-medium transition-colors ${view === l.id ? "" : "hover:opacity-80"}`}
              style={view === l.id ? { background: "var(--p1-soft)", color: "var(--p1)" } : { color: "var(--text)" }}>
              {l.label}
            </button>
          ))}
        </nav>
        <div className="flex items-center gap-2.5">
          <ThemeToggle theme={theme} toggleTheme={toggleTheme} />
          {user ? (
            <button onClick={() => goto("dashboard")} className="fs-btn-primary fs-focusable px-4 py-2.5 text-sm flex items-center gap-2">
              <LayoutGrid size={15} /> Dashboard
            </button>
          ) : (
            <>
              <button onClick={() => { ctx.setAuthMode("login"); goto("auth"); }} className="fs-focusable hidden sm:block text-sm font-semibold px-4 py-2.5">Log in</button>
              <button onClick={() => { ctx.setAuthMode("register"); goto("auth"); }} className="fs-btn-primary fs-focusable px-4 py-2.5 text-sm">Get Started</button>
            </>
          )}
          <button className="lg:hidden fs-focusable w-10 h-10 rounded-full flex items-center justify-center fs-border border" onClick={() => setMobileNavOpen(v => !v)}>
            {mobileNavOpen ? <X size={18} /> : <Menu size={18} />}
          </button>
        </div>
      </div>
      {mobileNavOpen && (
        <div className="lg:hidden px-5 pb-4 flex flex-col gap-1 border-t fs-border">
          {NAV_LINKS.map(l => (
            <button key={l.id} onClick={() => goto(l.id)} className="text-left px-3 py-2.5 rounded-xl text-sm font-medium" style={view === l.id ? { background: "var(--p1-soft)", color: "var(--p1)" } : {}}>
              {l.label}
            </button>
          ))}
          {!user && <button onClick={() => { ctx.setAuthMode("login"); goto("auth"); }} className="text-left px-3 py-2.5 rounded-xl text-sm font-semibold">Log in</button>}
        </div>
      )}
    </header>
  );
}

/* ============================================================================
   HOME PAGE
============================================================================ */
function HomePage({ ctx }) {
  const { goto, listings, reviews } = ctx;
  return (
    <>
      <Hero ctx={ctx} />
      <TrustStrip />
      <ServicesGrid ctx={ctx} compact />
      <CareTipsPreview ctx={ctx} />
      <FeaturedProducts ctx={ctx} />
      <AdoptablePreview ctx={ctx} listings={listings} goto={goto} />
      <VetsPreview ctx={ctx} />
      <Testimonials reviews={reviews} />
      <CTABand ctx={ctx} />
    </>
  );
}

function Hero({ ctx }) {
  const { goto, theme } = ctx;
  const mainPhoto = theme === "dark" ? PHOTOS.dogDark : PHOTOS.dogLight;
  const accentPhoto = theme === "dark" ? PHOTOS.cat2 : PHOTOS.cat1;
  return (
    <section className="relative overflow-hidden" style={{ background: "var(--hero-bg)" }}>
      <HeroDecor theme={theme} />
      <div className="max-w-7xl mx-auto px-5 md:px-8 pt-14 pb-20 md:pt-20 md:pb-28 grid lg:grid-cols-2 gap-14 items-center relative z-10">
        <div className="fs-anim-in">
          <div className="inline-flex items-center gap-2 fs-chip mb-5" style={{ background: "var(--p1-soft)", color: "var(--p1)" }}>
            <Sparkles size={14} /> Every paw &amp; wing, one shield of love
          </div>
          <h1 className="fs-display text-[2.6rem] leading-[1.08] sm:text-6xl sm:leading-[1.05] font-semibold mb-6">
            Complete care for<br />your <span className="fs-grad-text">furry family</span>
          </h1>
          <p className="fs-muted text-lg max-w-md mb-8 leading-relaxed">
            Track health records, book trusted vets, shop essentials and find your next best friend — all from one gentle, unified home.
          </p>
          <div className="flex flex-wrap gap-3 mb-10">
            <button onClick={() => { ctx.setAuthMode("register"); goto("auth"); }} className="fs-btn-primary fs-focusable fs-tap px-7 py-3.5 flex items-center gap-2">
              Book an Appointment <ArrowRight size={16} />
            </button>
            <button onClick={() => goto("adopt-public")} className="fs-btn-outline fs-focusable fs-tap px-7 py-3.5 flex items-center gap-2">
              <Heart size={16} /> Meet Adoptable Pets
            </button>
          </div>
          <div className="flex flex-wrap gap-x-8 gap-y-3">
            {[["BadgeCheck", "Trusted Veterinarians"], ["Shield", "Safe & Modern Facilities"], ["Heart", "Personalized Care"]].map(([icon, label], i) => {
              const Ic = icon === "BadgeCheck" ? BadgeCheck : icon === "Shield" ? Shield : Heart;
              return (
                <div key={i} className="flex items-center gap-2 text-sm font-medium">
                  <Ic size={16} style={{ color: "var(--p1)" }} /> {label}
                </div>
              );
            })}
          </div>
        </div>

        <div className="relative h-[420px] sm:h-[480px] fs-anim-pop" style={{ animationDelay: "120ms" }}>
          <div className="absolute inset-0 rounded-[40px] overflow-hidden" style={{ boxShadow: "var(--shadow)" }}>
            <img key={mainPhoto} src={mainPhoto} alt="Happy dog" className="w-full h-full object-cover fs-anim-fade" style={{ animationDuration: ".7s" }} />
            <div className="absolute inset-0" style={{ background: theme === "dark" ? "linear-gradient(180deg, rgba(11,10,20,0) 40%, rgba(11,10,20,.75) 100%)" : "linear-gradient(180deg, rgba(0,0,0,0) 55%, rgba(20,15,40,.35) 100%)" }} />
            <div className="absolute top-6 left-6 text-3xl fs-float drop-shadow-lg" style={{ filter: theme === "dark" ? "drop-shadow(0 0 10px var(--p1))" : "none" }}>🐾</div>
            <div className="absolute bottom-24 right-7 text-2xl fs-float-delay drop-shadow-lg">🦴</div>
          </div>

          <div className="absolute -bottom-8 -right-4 sm:-right-8 w-28 h-28 sm:w-36 sm:h-36 rounded-full overflow-hidden border-4 fs-bob" style={{ borderColor: "var(--surface)", boxShadow: "var(--shadow)" }}>
            <img key={accentPhoto} src={accentPhoto} alt="Happy cat" className="w-full h-full object-cover fs-anim-fade" />
          </div>

          <div className="absolute -bottom-6 -left-4 sm:-left-8 fs-card p-4 w-52 fs-anim-slide" style={{ animationDelay: "260ms" }}>
            <div className="flex items-center gap-2 mb-1">
              <div className="w-8 h-8 rounded-full flex items-center justify-center" style={{ background: "var(--p4-soft)" }}>
                <Calendar size={15} style={{ color: "var(--p4)" }} />
              </div>
              <span className="text-xs font-semibold">Next Appointment</span>
            </div>
            <div className="text-sm font-medium">Luna · Checkup</div>
            <div className="text-xs fs-muted">Fri, 10:00 AM · Dr. Sara Ahmed</div>
          </div>

          <div className="absolute -top-4 -right-2 sm:-right-6 fs-card p-3.5 flex items-center gap-2.5 fs-anim-slide" style={{ animationDelay: "380ms" }}>
            <div className="w-9 h-9 rounded-full flex items-center justify-center" style={{ background: "var(--p3-soft)" }}>
              <Syringe size={16} style={{ color: "var(--p3)" }} />
            </div>
            <div>
              <div className="text-xs font-semibold">Vaccination due</div>
              <div className="text-[11px] fs-muted">in 6 days</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

/* Theme-specific ambient decoration: colourful blobs for light, neon paw glow for dark */
function HeroDecor({ theme }) {
  if (theme === "dark") {
    return (
      <div className="absolute inset-0 pointer-events-none overflow-hidden" aria-hidden="true">
        <div className="absolute top-10 left-[8%] w-72 h-72 rounded-full fs-bob" style={{ background: "radial-gradient(circle, rgba(177,140,255,.22), transparent 70%)", filter: "blur(4px)" }} />
        <div className="absolute bottom-0 right-[6%] w-96 h-96 rounded-full fs-bob" style={{ background: "radial-gradient(circle, rgba(255,127,176,.16), transparent 70%)", animationDelay: "1s" }} />
        <PawPrint className="absolute top-24 right-[28%] fs-float" size={34} style={{ color: "var(--p1)", opacity: .5, filter: "drop-shadow(0 0 12px var(--p1))" }} />
        <PawPrint className="absolute bottom-16 left-[38%] fs-float-delay" size={22} style={{ color: "var(--p2)", opacity: .45, filter: "drop-shadow(0 0 10px var(--p2))" }} />
        <PawPrint className="absolute top-1/2 left-[4%] fs-bob" size={18} style={{ color: "var(--p3)", opacity: .4, filter: "drop-shadow(0 0 8px var(--p3))" }} />
      </div>
    );
  }
  return (
    <div className="absolute inset-0 pointer-events-none overflow-hidden" aria-hidden="true">
      <div className="absolute -top-16 -left-10 w-80 h-80 rounded-full fs-bob" style={{ background: "var(--p3-soft)", opacity: .7 }} />
      <div className="absolute top-10 right-0 w-64 h-64 rounded-full fs-bob" style={{ background: "var(--p1-soft)", animationDelay: ".8s" }} />
      <div className="absolute bottom-0 left-[20%] w-52 h-52 rounded-full fs-bob" style={{ background: "var(--p4-soft)", animationDelay: "1.6s", opacity: .8 }} />
      <PawPrint className="absolute top-28 left-[12%] fs-float" size={26} style={{ color: "var(--p1)", opacity: .35 }} />
      <PawPrint className="absolute bottom-24 right-[15%] fs-float-delay" size={20} style={{ color: "var(--p2)", opacity: .35 }} />
    </div>
  );
}

function TrustStrip() {
  const stats = [["2.5K+", "Happy Pets"], ["1.2K+", "Satisfied Owners"], ["98%", "Care Success Rate"], ["5.0", "Average Rating"]];
  return (
    <section className="border-y fs-border" style={{ background: "var(--surface)" }}>
      <div className="max-w-7xl mx-auto px-5 md:px-8 py-8 grid grid-cols-2 md:grid-cols-4 gap-6">
        {stats.map(([n, l], i) => (
          <AnimIn i={i} key={i} className="text-center">
            <div className="fs-display text-3xl font-semibold fs-grad-text">{n}</div>
            <div className="text-xs fs-muted mt-1 font-medium">{l}</div>
          </AnimIn>
        ))}
      </div>
    </section>
  );
}

function SectionHead({ eyebrow, title, sub, action }) {
  return (
    <div className="flex flex-wrap items-end justify-between gap-4 mb-9">
      <div>
        {eyebrow && <div className="flex items-center gap-2 mb-2"><PawPrint size={15} style={{ color: "var(--p1)" }} /><span className="text-sm font-semibold" style={{ color: "var(--p1)" }}>{eyebrow}</span></div>}
        <h2 className="fs-display text-3xl font-semibold">{title}</h2>
        {sub && <p className="fs-muted mt-2 max-w-lg">{sub}</p>}
      </div>
      {action}
    </div>
  );
}

const SERVICES = [
  { icon: Stethoscope, title: "Veterinary Care", desc: "Checkups, diagnostics and emergency care from trusted vets.", color: "p1", photo: PHOTOS.vetDog },
  { icon: Scissors, title: "Grooming", desc: "Keep coats, claws and skin fresh, clean and fabulous.", color: "p2", photo: PHOTOS.cat3 },
  { icon: Home, title: "Care Center", desc: "Feeding, hygiene and exercise guides tailored to your pet.", color: "p3", photo: PHOTOS.dogAutumn },
  { icon: ShoppingCart, title: "Pet Shop", desc: "Food, toys and health essentials, delivered to your dashboard cart.", color: "p4", photo: PHOTOS.rabbit1 },
];

function ServicesGrid({ ctx, compact }) {
  const { goto } = ctx;
  return (
    <section className="max-w-7xl mx-auto px-5 md:px-8 py-16 md:py-20">
      <SectionHead eyebrow="Our Services" title="Everything your pet needs, under one roof" sub="From daily care to emergency visits — FurShield brings it together." action={
        <button onClick={() => goto("services")} className="fs-focusable text-sm font-semibold flex items-center gap-1" style={{ color: "var(--p1)" }}>View all <ChevronRight size={15} /></button>
      } />
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
        {SERVICES.map((s, i) => (
          <AnimIn i={i} key={i} className="fs-card fs-card-hover overflow-hidden cursor-pointer" onClick={() => goto("services")}>
            <div className="h-28 relative overflow-hidden">
              <img src={s.photo} alt={s.title} className="w-full h-full object-cover" loading="lazy" />
              <div className="absolute inset-0" style={{ background: `linear-gradient(180deg, transparent 40%, var(--surface) 100%)` }} />
              <div className="absolute bottom-2 left-4 w-10 h-10 rounded-2xl flex items-center justify-center fs-icon-pop" style={{ background: `var(--${s.color})`, boxShadow: "var(--shadow-sm)" }}>
                <s.icon size={18} color="#fff" />
              </div>
            </div>
            <div className="p-6 pt-4">
              <h3 className="font-semibold text-lg mb-1.5">{s.title}</h3>
              <p className="fs-muted text-sm leading-relaxed mb-4">{s.desc}</p>
              <div className="flex items-center gap-1 text-sm font-semibold" style={{ color: `var(--${s.color})` }}>
                Learn more <ChevronRight size={14} className="group-hover:translate-x-1 transition-transform" />
              </div>
            </div>
          </AnimIn>
        ))}
      </div>
    </section>
  );
}

function CareTipsPreview({ ctx }) {
  return (
    <section style={{ background: "var(--bg-soft)" }} className="py-16 md:py-20 border-y fs-border">
      <div className="max-w-7xl mx-auto px-5 md:px-8">
        <SectionHead eyebrow="Care Center" title="Expert tips, right when you need them" sub="Bite-sized guides on feeding, hygiene and exercise from our care team." />
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {CARE_ARTICLES.slice(0, 3).map((a, i) => (
            <AnimIn i={i} key={a.id} className="fs-card fs-card-hover p-6">
              <span className="fs-chip inline-block mb-3" style={{ background: "var(--p1-soft)", color: "var(--p1)" }}>{a.cat}</span>
              <h4 className="font-semibold mb-1.5">{a.title}</h4>
              <p className="fs-muted text-sm">{a.desc}</p>
            </AnimIn>
          ))}
        </div>
      </div>
    </section>
  );
}

function FeaturedProducts({ ctx }) {
  const { products, addToCart, user, goto } = ctx;
  const featured = products.slice(0, 4);
  return (
    <section className="max-w-7xl mx-auto px-5 md:px-8 py-16 md:py-20">
      <SectionHead eyebrow="Shop" title="Everyday essentials, expert-picked" action={
        <button onClick={() => goto("shop-public")} className="fs-focusable text-sm font-semibold flex items-center gap-1" style={{ color: "var(--p1)" }}>Browse shop <ChevronRight size={15} /></button>
      } />
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
        {featured.map((p, i) => (
          <AnimIn i={i} key={p.id} className="fs-card fs-card-hover p-5 flex flex-col">
            <div className="w-full h-28 rounded-2xl flex items-center justify-center text-5xl mb-4 fs-icon-pop" style={{ background: "var(--surface-2)" }}>{p.icon}</div>
            <span className="fs-chip w-fit mb-2" style={{ background: "var(--p4-soft)", color: "var(--p4)" }}>{p.category}</span>
            <h4 className="font-semibold text-sm mb-1 leading-snug">{p.name}</h4>
            <div className="mt-auto pt-3 flex items-center justify-between">
              <span className="font-semibold fs-display">{fmtMoney(p.price)}</span>
              <button onClick={() => user ? addToCart(p.id) : goto("auth")} className="fs-btn-primary fs-focusable fs-tap w-9 h-9 flex items-center justify-center !rounded-full">
                <Plus size={16} />
              </button>
            </div>
          </AnimIn>
        ))}
      </div>
    </section>
  );
}

function AdoptablePreview({ ctx, listings, goto }) {
  const available = listings.filter(l => l.status === "Available").slice(0, 4);
  return (
    <section style={{ background: "var(--bg-soft)" }} className="py-16 md:py-20 border-y fs-border">
      <div className="max-w-7xl mx-auto px-5 md:px-8">
        <SectionHead eyebrow="Adoption" title="Looking for their forever home" sub="Meet pets currently in shelter care, ready to be loved." action={
          <button onClick={() => goto("adopt-public")} className="fs-focusable text-sm font-semibold flex items-center gap-1" style={{ color: "var(--p1)" }}>See all <ChevronRight size={15} /></button>
        } />
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {available.map((p, i) => (
            <AnimIn i={i} key={p.id} className="fs-card fs-card-hover overflow-hidden">
              <div className="h-32 overflow-hidden" style={{ background: "var(--surface-2)" }}>
                <AdoptThumb species={p.species} seed={p.id} emoji={p.image} />
              </div>
              <div className="p-5">
                <div className="flex items-center justify-between mb-1">
                  <h4 className="font-semibold">{p.petName}</h4>
                  <span className="fs-chip" style={{ background: "var(--p4-soft)", color: "var(--p4)" }}>{p.status}</span>
                </div>
                <p className="text-xs fs-muted">{p.breed} · {p.age}</p>
              </div>
            </AnimIn>
          ))}
        </div>
      </div>
    </section>
  );
}

function VetsPreview({ ctx }) {
  const vets = ctx.accounts.filter(a => a.role === "vet");
  return (
    <section className="max-w-7xl mx-auto px-5 md:px-8 py-16 md:py-20">
      <SectionHead eyebrow="Our Team" title="Meet our veterinarians" sub="Experienced professionals ready to care for your companion." />
      <div className="grid lg:grid-cols-[1fr_1.15fr] gap-5">
        <div className="grid sm:grid-cols-2 gap-5">
          {vets.map((v, i) => (
            <AnimIn i={i} key={v.id} className="fs-card fs-card-hover p-6 flex gap-4 items-start">
              <div className="w-14 h-14 rounded-2xl flex items-center justify-center text-2xl shrink-0 fs-icon-pop" style={{ background: "var(--grad)" }}>👩‍⚕️</div>
              <div>
                <h4 className="font-semibold">{v.name}</h4>
                <p className="text-xs fs-muted mb-2">{v.specialization} · {v.experience}</p>
                <div className="flex items-center gap-1 text-xs font-medium">
                  {[...Array(5)].map((_, i2) => <Star key={i2} size={12} fill="var(--p3)" color="var(--p3)" />)}
                  <span className="fs-muted ml-1">5.0</span>
                </div>
              </div>
            </AnimIn>
          ))}
        </div>
        <AnimIn i={2} className="fs-card fs-card-hover relative overflow-hidden min-h-[220px]">
          <img src={PHOTOS.vetDog} alt="Veterinarian caring for a dog" className="w-full h-full object-cover absolute inset-0" loading="lazy" />
          <div className="absolute inset-0" style={{ background: "linear-gradient(100deg, rgba(0,0,0,.55) 20%, rgba(0,0,0,.05) 75%)" }} />
          <div className="relative z-10 p-7 h-full flex flex-col justify-end">
            <h4 className="fs-display text-white text-xl font-semibold mb-1">Compassionate, hands-on care</h4>
            <p className="text-white/85 text-sm max-w-xs">Every checkup is unhurried — gentle handling, clear explanations, real answers.</p>
          </div>
        </AnimIn>
      </div>
    </section>
  );
}

function Testimonials({ reviews }) {
  return (
    <section style={{ background: "var(--bg-soft)" }} className="py-16 md:py-20 border-y fs-border">
      <div className="max-w-7xl mx-auto px-5 md:px-8">
        <SectionHead eyebrow="Testimonials" title="What pet parents say" />
        <div className="grid sm:grid-cols-2 gap-5">
          {reviews.map((r, i) => (
            <AnimIn i={i} key={r.id} className="fs-card fs-card-hover p-6">
              <div className="flex items-center gap-1 mb-3">{[...Array(r.rating)].map((_, i2) => <Star key={i2} size={13} fill="var(--p3)" color="var(--p3)" />)}</div>
              <p className="text-sm leading-relaxed mb-4">"{r.comment}"</p>
              <div className="text-sm font-semibold">{r.author}</div>
              <div className="text-xs fs-muted">on {r.target}</div>
            </AnimIn>
          ))}
        </div>
      </div>
    </section>
  );
}

function CTABand({ ctx }) {
  return (
    <section className="max-w-7xl mx-auto px-5 md:px-8 py-16 md:py-20">
      <div className="fs-card p-10 md:p-14 text-center relative overflow-hidden" style={{ background: "var(--grad)" }}>
        <div className="relative z-10">
          <h2 className="fs-display text-3xl md:text-4xl font-semibold text-white mb-3">Ready to give them the best care?</h2>
          <p className="text-white/85 max-w-md mx-auto mb-7">Join FurShield today — it takes less than a minute to set up your pet's profile.</p>
          <button onClick={() => { ctx.setAuthMode("register"); ctx.goto("auth"); }} className="bg-white fs-focusable px-8 py-3.5 rounded-full font-semibold" style={{ color: "var(--p1)" }}>
            Create Free Account
          </button>
        </div>
        <div className="absolute -bottom-10 -right-10 text-9xl opacity-20 rotate-12">🐾</div>
        <div className="absolute -top-10 -left-6 text-8xl opacity-20 -rotate-12">🐾</div>
      </div>
    </section>
  );
}

function Footer({ ctx }) {
  const { goto } = ctx;
  return (
    <footer className="border-t fs-border" style={{ background: "var(--surface)" }}>
      <div className="max-w-7xl mx-auto px-5 md:px-8 py-12 grid sm:grid-cols-2 lg:grid-cols-4 gap-10">
        <div>
          <Logo />
          <p className="fs-muted text-sm mt-4 max-w-xs">A unified home for pet owners, veterinarians and shelters — because every paw deserves a shield of love.</p>
        </div>
        <div>
          <h5 className="font-semibold text-sm mb-3">Explore</h5>
          <div className="flex flex-col gap-2 text-sm fs-muted">
            {NAV_LINKS.map(l => <button key={l.id} onClick={() => goto(l.id)} className="text-left hover:opacity-70 w-fit">{l.label}</button>)}
          </div>
        </div>
        <div>
          <h5 className="font-semibold text-sm mb-3">Roles</h5>
          <div className="flex flex-col gap-2 text-sm fs-muted">
            <button onClick={() => { ctx.setAuthRole("owner"); ctx.setAuthMode("login"); goto("auth"); }} className="text-left hover:opacity-70 w-fit">Pet Owner Login</button>
            <button onClick={() => { ctx.setAuthRole("vet"); ctx.setAuthMode("login"); goto("auth"); }} className="text-left hover:opacity-70 w-fit">Veterinarian Login</button>
            <button onClick={() => { ctx.setAuthRole("shelter"); ctx.setAuthMode("login"); goto("auth"); }} className="text-left hover:opacity-70 w-fit">Shelter Login</button>
          </div>
        </div>
        <div>
          <h5 className="font-semibold text-sm mb-3">Contact</h5>
          <div className="flex flex-col gap-2 text-sm fs-muted">
            <div className="flex items-center gap-2"><Phone size={14} /> 021-111-PAWS</div>
            <div className="flex items-center gap-2"><Mail size={14} /> hello@furshield.app</div>
            <div className="flex items-center gap-2"><MapPin size={14} /> Karachi, Pakistan</div>
          </div>
        </div>
      </div>
      <div className="border-t fs-border py-5 text-center text-xs fs-muted">© 2026 FurShield · Aptech TechWiz 6 Project · Frontend demo, no payment/delivery included.</div>
    </footer>
  );
}

/* ============================================================================
   SERVICES / SHOP-PUBLIC / ADOPT-PUBLIC / ABOUT / CONTACT
============================================================================ */

function PageHeader({ title, sub }) {
  return (
    <div className="border-b fs-border" style={{ background: "var(--hero-bg)" }}>
      <div className="max-w-7xl mx-auto px-5 md:px-8 py-14 md:py-16">
        <h1 className="fs-display text-4xl font-semibold mb-2">{title}</h1>
        {sub && <p className="fs-muted max-w-xl">{sub}</p>}
      </div>
    </div>
  );
}

function ServicesPage({ ctx }) {
  return (
    <div>
      <PageHeader title="Our Services" sub="Everything your pet needs, from checkups to companionship." />
      <div className="max-w-7xl mx-auto px-5 md:px-8 py-14 grid sm:grid-cols-2 gap-6">
        {SERVICES.map((s, i) => (
          <AnimIn i={i} key={i} className="fs-card fs-card-hover overflow-hidden flex">
            <div className="w-36 shrink-0 relative overflow-hidden">
              <img src={s.photo} alt={s.title} className="w-full h-full object-cover" loading="lazy" />
            </div>
            <div className="p-7 flex gap-4">
              <div className="w-12 h-12 rounded-2xl flex items-center justify-center shrink-0 fs-icon-pop" style={{ background: `var(--${s.color}-soft)` }}>
                <s.icon size={20} style={{ color: `var(--${s.color})` }} />
              </div>
              <div>
                <h3 className="font-semibold text-xl mb-2">{s.title}</h3>
                <p className="fs-muted leading-relaxed">{s.desc}</p>
              </div>
            </div>
          </AnimIn>
        ))}
      </div>
      <CTABand ctx={ctx} />
    </div>
  );
}

function AdoptThumb({ species, seed = 0, emoji, className = "" }) {
  const photo = speciesPhoto(species, seed);
  if (photo) return <img src={photo} alt={species} className={`w-full h-full object-cover ${className}`} loading="lazy" />;
  return <span className={`text-6xl flex items-center justify-center w-full h-full ${className}`}>{emoji}</span>;
}

function ProductCard({ p, onAdd, i = 0 }) {
  return (
    <AnimIn i={i} className="fs-card fs-card-hover p-5 flex flex-col">
      <div className="w-full h-28 rounded-2xl flex items-center justify-center text-5xl mb-4 fs-icon-pop" style={{ background: "var(--surface-2)" }}>{p.icon}</div>
      <span className="fs-chip w-fit mb-2" style={{ background: "var(--p4-soft)", color: "var(--p4)" }}>{p.category}</span>
      <h4 className="font-semibold text-sm mb-1 leading-snug">{p.name}</h4>
      <p className="fs-muted text-xs mb-3 leading-relaxed">{p.desc}</p>
      <div className="mt-auto pt-2 flex items-center justify-between">
        <span className="font-semibold fs-display">{fmtMoney(p.price)}</span>
        <button onClick={onAdd} className="fs-btn-primary fs-focusable fs-tap px-3.5 py-2 text-xs flex items-center gap-1">
          <Plus size={14} /> Add
        </button>
      </div>
    </AnimIn>
  );
}

function ShopPublicPage({ ctx }) {
  const { products, user, goto, addToCart } = ctx;
  const [cat, setCat] = useState("All");
  const [q, setQ] = useState("");
  const cats = ["All", ...new Set(products.map(p => p.category))];
  const filtered = products.filter(p => (cat === "All" || p.category === cat) && p.name.toLowerCase().includes(q.toLowerCase()));
  return (
    <div>
      <PageHeader title="Shop" sub="Food, grooming, toys, health & training essentials — browse and build your cart." />
      <div className="max-w-7xl mx-auto px-5 md:px-8 py-12">
        <div className="flex flex-wrap gap-3 items-center justify-between mb-8">
          <div className="flex flex-wrap gap-2">
            {cats.map(c => (
              <button key={c} onClick={() => setCat(c)} className="fs-chip fs-focusable border fs-border" style={cat === c ? { background: "var(--p1)", color: "#fff", borderColor: "var(--p1)" } : {}}>{c}</button>
            ))}
          </div>
          <div className="relative w-full sm:w-64">
            <Search size={15} className="absolute left-3.5 top-1/2 -translate-y-1/2 fs-muted" />
            <input value={q} onChange={e => setQ(e.target.value)} placeholder="Search products..." className="fs-input pl-10" />
          </div>
        </div>
        {!user && <div className="fs-card p-4 mb-6 flex items-center gap-3 text-sm" style={{ background: "var(--p1-soft)" }}>
          <Info size={16} style={{ color: "var(--p1)" }} /> Log in as a pet owner to add items to your cart and place an order.
        </div>}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {filtered.map((p, i) => <ProductCard key={p.id} p={p} i={i} onAdd={() => user ? addToCart(p.id) : goto("auth")} />)}
        </div>
        {filtered.length === 0 && <div className="text-center py-16 fs-muted fs-anim-fade">No products match your search.</div>}
      </div>
    </div>
  );
}

function AdoptPublicPage({ ctx }) {
  const { listings } = ctx;
  const [filter, setFilter] = useState("All");
  const species = ["All", ...new Set(listings.map(l => l.species))];
  const filtered = listings.filter(l => filter === "All" || l.species === filter);
  return (
    <div>
      <PageHeader title="Adopt a Companion" sub="Every listing here comes from a verified shelter, ready for a forever home." />
      <div className="max-w-7xl mx-auto px-5 md:px-8 py-12">
        <div className="flex flex-wrap gap-2 mb-8">
          {species.map(s => (
            <button key={s} onClick={() => setFilter(s)} className="fs-chip fs-focusable border fs-border" style={filter === s ? { background: "var(--p1)", color: "#fff", borderColor: "var(--p1)" } : {}}>{s}</button>
          ))}
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filtered.map((l, i) => (
            <AnimIn i={i} key={l.id} className="fs-card fs-card-hover overflow-hidden">
              <div className="h-40 overflow-hidden" style={{ background: "var(--surface-2)" }}>
                <AdoptThumb species={l.species} seed={l.id} emoji={l.image} />
              </div>
              <div className="p-6">
                <div className="flex items-center justify-between mb-2">
                  <h4 className="font-semibold text-lg">{l.petName}</h4>
                  <span className="fs-chip" style={{ background: l.status === "Available" ? "var(--p4-soft)" : "var(--p3-soft)", color: l.status === "Available" ? "var(--p4)" : "var(--p3)" }}>{l.status}</span>
                </div>
                <p className="text-sm fs-muted mb-1">{l.breed} · {l.age}</p>
                <p className="text-xs fs-muted">{l.health}</p>
              </div>
            </AnimIn>
          ))}
        </div>
      </div>
    </div>
  );
}

function AboutPage({ ctx }) {
  return (
    <div>
      <PageHeader title="About FurShield" sub="Built for TechWiz 6 — a unified pet care platform for owners, veterinarians and shelters." />
      <div className="max-w-4xl mx-auto px-5 md:px-8 py-14">
        <div className="grid grid-cols-3 gap-3 mb-10 fs-anim-in">
          <div className="h-40 sm:h-56 rounded-3xl overflow-hidden col-span-2 row-span-2"><img src={PHOTOS.dogAutumn} alt="Dog" className="w-full h-full object-cover" loading="lazy" /></div>
          <div className="h-[76px] sm:h-[108px] rounded-3xl overflow-hidden"><img src={PHOTOS.cat3} alt="Cat" className="w-full h-full object-cover" loading="lazy" /></div>
          <div className="h-[76px] sm:h-[108px] rounded-3xl overflow-hidden"><img src={PHOTOS.rabbit1} alt="Rabbit" className="w-full h-full object-cover" loading="lazy" /></div>
        </div>
        <p className="leading-relaxed mb-6">FurShield brings together the people who care for animals every day: the owners who love them at home, the veterinarians who keep them healthy, and the shelters who give them a second chance. Our mission is to replace scattered notebooks and forgotten reminders with one calm, organized place.</p>
        <div className="grid sm:grid-cols-3 gap-5 my-10">
          {[["Care", Heart, "p2"], ["Trust", Shield, "p1"], ["Community", Users, "p4"]].map(([label, Icon, c], i) => (
            <AnimIn i={i} key={i} className="fs-card fs-card-hover p-6 text-center">
              <div className="w-12 h-12 mx-auto rounded-2xl flex items-center justify-center mb-3 fs-icon-pop" style={{ background: `var(--${c}-soft)` }}>
                <Icon size={20} style={{ color: `var(--${c})` }} />
              </div>
              <div className="font-semibold">{label}</div>
            </AnimIn>
          ))}
        </div>
        <p className="leading-relaxed fs-muted text-sm">This build fulfills the FurShield SRS (v1.0): pet profile & health record management, appointment booking, care resources, a product shop, and shelter adoption tools — all with role-based dashboards for owners, veterinarians and shelters.</p>
      </div>
    </div>
  );
}

function ContactPage({ ctx }) {
  const { notify } = ctx;
  const [form, setForm] = useState({ name: "", email: "", message: "" });
  return (
    <div>
      <PageHeader title="Contact Us" sub="Questions, feedback or partnership ideas — we'd love to hear from you." />
      <div className="max-w-6xl mx-auto px-5 md:px-8 py-14 grid lg:grid-cols-2 gap-10">
        <form onSubmit={e => { e.preventDefault(); notify("Message sent — our team will reach out soon."); setForm({ name: "", email: "", message: "" }); }} className="fs-card p-7 space-y-4">
          <div>
            <label className="text-sm font-medium mb-1.5 block">Name</label>
            <input required value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} className="fs-input" placeholder="Your name" />
          </div>
          <div>
            <label className="text-sm font-medium mb-1.5 block">Email</label>
            <input required type="email" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} className="fs-input" placeholder="you@example.com" />
          </div>
          <div>
            <label className="text-sm font-medium mb-1.5 block">Message</label>
            <textarea required rows={4} value={form.message} onChange={e => setForm({ ...form, message: e.target.value })} className="fs-input resize-none" placeholder="How can we help?" />
          </div>
          <button className="fs-btn-primary fs-focusable px-6 py-3 w-full">Send Message</button>
        </form>
        <div className="space-y-5">
          <div className="fs-card p-6 flex items-center gap-4">
            <div className="w-11 h-11 rounded-2xl flex items-center justify-center" style={{ background: "var(--p1-soft)" }}><MapPin size={18} style={{ color: "var(--p1)" }} /></div>
            <div><div className="font-semibold text-sm">Our Office</div><div className="fs-muted text-sm">Block 4, Gulshan-e-Iqbal, Karachi</div></div>
          </div>
          <div className="fs-card p-6 flex items-center gap-4">
            <div className="w-11 h-11 rounded-2xl flex items-center justify-center" style={{ background: "var(--p2-soft)" }}><Phone size={18} style={{ color: "var(--p2)" }} /></div>
            <div><div className="font-semibold text-sm">Phone</div><div className="fs-muted text-sm">021-111-PAWS (7297)</div></div>
          </div>
          <div className="fs-card p-6 flex items-center gap-4">
            <div className="w-11 h-11 rounded-2xl flex items-center justify-center" style={{ background: "var(--p3-soft)" }}><Mail size={18} style={{ color: "var(--p3)" }} /></div>
            <div><div className="font-semibold text-sm">Email</div><div className="fs-muted text-sm">hello@furshield.app</div></div>
          </div>
          <div className="fs-card overflow-hidden h-48 flex items-center justify-center fs-muted text-sm" style={{ background: "var(--surface-2)" }}>
            <MapPin size={20} className="mr-2" /> Map preview (Google Maps / OpenStreetMap)
          </div>
        </div>
      </div>
    </div>
  );
}

/* ============================================================================
   AUTH PAGE
============================================================================ */
function AuthPage({ ctx }) {
  const { authMode, setAuthMode, authRole, setAuthRole, doLogin, doRegister, goto } = ctx;
  const [showPw, setShowPw] = useState(false);
  const [login, setLoginData] = useState({ email: "", password: "" });
  const [reg, setReg] = useState({ name: "", email: "", password: "", phone: "", address: "", specialization: "", experience: "" });

  const roles = [
    { id: "owner", label: "Pet Owner", icon: User },
    { id: "vet", label: "Veterinarian", icon: Stethoscope },
    { id: "shelter", label: "Shelter", icon: Building2 },
  ];

  const submitLogin = (e) => { e.preventDefault(); doLogin(login.email, login.password, authRole); };
  const submitRegister = (e) => {
    e.preventDefault();
    const payload = { role: authRole, name: reg.name, email: reg.email, password: reg.password, phone: reg.phone, address: reg.address };
    if (authRole === "vet") { payload.specialization = reg.specialization || "General Practice"; payload.experience = reg.experience || "1 year"; payload.slots = []; payload.bio = ""; }
    doRegister(payload);
  };

  return (
    <div className="min-h-[calc(100vh-72px)] grid lg:grid-cols-2" style={{ background: "var(--hero-bg)" }}>
      <div className="hidden lg:flex flex-col justify-between p-12 relative overflow-hidden" style={{ background: "var(--grad)" }}>
        <button onClick={() => goto("home")} className="flex items-center gap-2 text-white fs-focusable w-fit">
          <div className="w-9 h-9 rounded-xl bg-white/20 flex items-center justify-center"><PawPrint size={18} color="#fff" /></div>
          <span className="fs-display font-semibold text-lg">FurShield</span>
        </button>
        <div className="text-white relative z-10">
          <h2 className="fs-display text-4xl font-semibold mb-4 leading-tight">Join a community that cares as much as you do.</h2>
          <p className="text-white/85 max-w-sm">Whether you're a pet parent, a vet, or a shelter — your dashboard is one login away.</p>
        </div>
        <div className="flex gap-2 text-white/70 text-sm relative z-10">
          <BadgeCheck size={16} /> Trusted by 2,500+ pet families
        </div>
        <div className="absolute -bottom-16 -right-16 text-[14rem] opacity-15 rotate-12">🐾</div>
      </div>

      <div className="flex items-center justify-center p-6 sm:p-12">
        <div className="w-full max-w-md">
          <div className="lg:hidden mb-8"><button onClick={() => goto("home")} className="fs-focusable"><Logo /></button></div>

          <div className="flex fs-card p-1 mb-7">
            {["login", "register"].map(m => (
              <button key={m} onClick={() => setAuthMode(m)} className="flex-1 py-2.5 rounded-2xl text-sm font-semibold fs-focusable"
                style={authMode === m ? { background: "var(--grad)", color: "#fff" } : { color: "var(--muted)" }}>
                {m === "login" ? "Log In" : "Register"}
              </button>
            ))}
          </div>

          <h3 className="fs-display text-2xl font-semibold mb-1">{authMode === "login" ? "Welcome back" : "Create your account"}</h3>
          <p className="fs-muted text-sm mb-6">{authMode === "login" ? "Log in to your FurShield dashboard." : "Choose your role to get started."}</p>

          <div className="grid grid-cols-3 gap-2 mb-6">
            {roles.map(r => (
              <button key={r.id} onClick={() => setAuthRole(r.id)} className="fs-focusable flex flex-col items-center gap-1.5 py-3 rounded-2xl border fs-border text-xs font-semibold"
                style={authRole === r.id ? { background: "var(--p1-soft)", borderColor: "var(--p1)", color: "var(--p1)" } : {}}>
                <r.icon size={18} /> {r.label}
              </button>
            ))}
          </div>

          {authMode === "login" ? (
            <form onSubmit={submitLogin} className="space-y-4">
              <div>
                <label className="text-sm font-medium mb-1.5 block">Email</label>
                <input required type="email" value={login.email} onChange={e => setLoginData({ ...login, email: e.target.value })} className="fs-input" placeholder="you@example.com" />
              </div>
              <div>
                <label className="text-sm font-medium mb-1.5 block">Password</label>
                <div className="relative">
                  <input required type={showPw ? "text" : "password"} value={login.password} onChange={e => setLoginData({ ...login, password: e.target.value })} className="fs-input pr-11" placeholder="••••••••" />
                  <button type="button" onClick={() => setShowPw(v => !v)} className="absolute right-3.5 top-1/2 -translate-y-1/2 fs-muted">{showPw ? <EyeOff size={16} /> : <Eye size={16} />}</button>
                </div>
              </div>
              <button className="fs-btn-primary fs-focusable w-full py-3 mt-2">Log In</button>
              <div className="fs-card p-3 text-xs fs-muted text-center" style={{ background: "var(--surface-2)" }}>
                Demo: <b>{authRole}@demo.com</b> / <b>demo123</b>
              </div>
            </form>
          ) : (
            <form onSubmit={submitRegister} className="space-y-4">
              <div>
                <label className="text-sm font-medium mb-1.5 block">{authRole === "shelter" ? "Shelter Name" : "Full Name"}</label>
                <input required value={reg.name} onChange={e => setReg({ ...reg, name: e.target.value })} className="fs-input" placeholder={authRole === "shelter" ? "Hope Paws Shelter" : "Jane Doe"} />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-sm font-medium mb-1.5 block">Email</label>
                  <input required type="email" value={reg.email} onChange={e => setReg({ ...reg, email: e.target.value })} className="fs-input" placeholder="you@example.com" />
                </div>
                <div>
                  <label className="text-sm font-medium mb-1.5 block">Contact Number</label>
                  <input required value={reg.phone} onChange={e => setReg({ ...reg, phone: e.target.value })} className="fs-input" placeholder="0300-1234567" />
                </div>
              </div>
              <div>
                <label className="text-sm font-medium mb-1.5 block">Address</label>
                <input required value={reg.address} onChange={e => setReg({ ...reg, address: e.target.value })} className="fs-input" placeholder="Street, Area, City" />
              </div>
              {authRole === "vet" && (
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-sm font-medium mb-1.5 block">Specialization</label>
                    <input value={reg.specialization} onChange={e => setReg({ ...reg, specialization: e.target.value })} className="fs-input" placeholder="e.g. Small Animal" />
                  </div>
                  <div>
                    <label className="text-sm font-medium mb-1.5 block">Experience</label>
                    <input value={reg.experience} onChange={e => setReg({ ...reg, experience: e.target.value })} className="fs-input" placeholder="e.g. 3 years" />
                  </div>
                </div>
              )}
              <div>
                <label className="text-sm font-medium mb-1.5 block">Password</label>
                <input required type={showPw ? "text" : "password"} value={reg.password} onChange={e => setReg({ ...reg, password: e.target.value })} className="fs-input" placeholder="Create a password" />
              </div>
              <button className="fs-btn-primary fs-focusable w-full py-3 mt-2">Create Account</button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}

/* ============================================================================
   DASHBOARD SHELL
============================================================================ */
const OWNER_TABS = [
  { id: "overview", label: "Overview", icon: LayoutGrid },
  { id: "pets", label: "My Pets", icon: PawPrint },
  { id: "health", label: "Health Records", icon: FileText },
  { id: "appointments", label: "Appointments", icon: Calendar },
  { id: "care", label: "Care Center", icon: Heart },
  { id: "shop", label: "Shop", icon: ShoppingCart },
  { id: "cart", label: "Cart & Orders", icon: Package },
];
const VET_TABS = [
  { id: "overview", label: "Overview", icon: LayoutGrid },
  { id: "profile", label: "My Profile", icon: User },
  { id: "appointments", label: "Appointments", icon: Calendar },
  { id: "logs", label: "Medical Logs", icon: ClipboardList },
];
const SHELTER_TABS = [
  { id: "overview", label: "Overview", icon: LayoutGrid },
  { id: "listings", label: "Adoptable Pets", icon: PawPrint },
  { id: "carelogs", label: "Care Logs", icon: ClipboardCheck },
  { id: "queries", label: "Adopter Queries", icon: MessageSquare },
];

function DashboardShell({ ctx }) {
  const { user, dashTab, setDashTab, theme, toggleTheme, doLogout, goto, cartCount } = ctx;
  const [sideOpen, setSideOpen] = useState(false);
  const tabs = user.role === "owner" ? OWNER_TABS : user.role === "vet" ? VET_TABS : SHELTER_TABS;
  const roleLabel = user.role === "owner" ? "Pet Owner" : user.role === "vet" ? "Veterinarian" : "Shelter";
  const roleIcon = user.role === "owner" ? User : user.role === "vet" ? Stethoscope : Building2;
  const RoleIcon = roleIcon;

  return (
    <div className="min-h-screen flex" style={{ background: "var(--bg)" }}>
      {/* Sidebar */}
      <aside className={`fixed lg:sticky top-0 h-screen w-72 shrink-0 border-r fs-border flex flex-col z-40 transition-transform duration-200 ${sideOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"}`} style={{ background: "var(--surface)" }}>
        <div className="p-6 border-b fs-border flex items-center justify-between">
          <button onClick={() => goto("home")} className="fs-focusable"><Logo /></button>
          <button className="lg:hidden fs-focusable" onClick={() => setSideOpen(false)}><X size={18} /></button>
        </div>
        <div className="p-5">
          <div className="fs-card p-4 flex items-center gap-3" style={{ background: "var(--surface-2)" }}>
            <div className="w-11 h-11 rounded-2xl flex items-center justify-center shrink-0" style={{ background: "var(--grad)" }}><RoleIcon size={19} color="#fff" /></div>
            <div className="min-w-0">
              <div className="font-semibold text-sm truncate">{user.name}</div>
              <div className="text-xs fs-muted">{roleLabel}</div>
            </div>
          </div>
        </div>
        <nav className="flex-1 px-4 space-y-1 fs-scroll overflow-y-auto">
          {tabs.map(t => (
            <button key={t.id} onClick={() => { setDashTab(t.id); setSideOpen(false); }} className={`fs-side-link fs-focusable w-full flex items-center justify-between px-4 py-3 text-sm font-medium ${dashTab === t.id ? "active" : ""}`}>
              <span className="flex items-center gap-3"><t.icon size={17} /> {t.label}</span>
              {t.id === "cart" && cartCount > 0 && <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-full" style={{ background: dashTab === t.id ? "rgba(255,255,255,0.25)" : "var(--p2)", color: "#fff" }}>{cartCount}</span>}
            </button>
          ))}
        </nav>
        <div className="p-4 border-t fs-border space-y-2">
          <button onClick={toggleTheme} className="fs-focusable fs-tap w-full flex items-center gap-3 px-4 py-3 rounded-2xl text-sm font-medium fs-side-link">
            {theme === "light" ? <Moon size={17} /> : <Sun size={17} className="fs-spin-slow" />} {theme === "light" ? "Dark mode" : "Light mode"}
          </button>
          <button onClick={doLogout} className="fs-focusable w-full flex items-center gap-3 px-4 py-3 rounded-2xl text-sm font-medium fs-side-link" style={{ color: "var(--p2)" }}>
            <LogOut size={17} /> Log out
          </button>
        </div>
      </aside>
      {sideOpen && <div className="fixed inset-0 bg-black/40 z-30 lg:hidden" onClick={() => setSideOpen(false)} />}

      {/* Content */}
      <div className="flex-1 min-w-0">
        <div className="sticky top-0 z-20 backdrop-blur-md border-b fs-border h-16 flex items-center justify-between px-5 md:px-8" style={{ background: "var(--navbg)" }}>
          <button className="lg:hidden fs-focusable" onClick={() => setSideOpen(true)}><Menu size={20} /></button>
          <div className="fs-display font-semibold capitalize hidden lg:block">{tabs.find(t => t.id === dashTab)?.label}</div>
          <div className="flex items-center gap-3">
            <div className="relative">
              <Bell size={19} className="fs-muted" />
              <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full animate-pulse" style={{ background: "var(--p2)" }} />
            </div>
          </div>
        </div>
        <div key={dashTab} className="p-5 md:p-8 max-w-6xl fs-page-enter">
          {user.role === "owner" && <OwnerDashboard ctx={ctx} />}
          {user.role === "vet" && <VetDashboard ctx={ctx} />}
          {user.role === "shelter" && <ShelterDashboard ctx={ctx} />}
        </div>
      </div>
    </div>
  );
}

function DashBanner({ role, photos = [], gradient, tagline }) {
  return (
    <div className="fs-card fs-anim-in relative overflow-hidden p-7 md:p-9 mb-7 flex items-center justify-between gap-6" style={{ background: gradient }}>
      <div className="relative z-10">
        <div className="fs-chip inline-flex items-center gap-1.5 mb-3 bg-white/20 text-white backdrop-blur-sm">
          <Sparkles size={12} /> {role} Dashboard
        </div>
        <h3 className="fs-display text-white text-2xl md:text-[1.7rem] font-semibold max-w-sm leading-snug">{tagline}</h3>
      </div>
      <div className="relative shrink-0 hidden sm:flex items-end gap-3 pr-2">
        {photos.map((src, i) => (
          <div key={i} className="rounded-full overflow-hidden border-4 border-white/40 fs-bob shadow-xl"
            style={{ width: i === 1 ? 84 : 60, height: i === 1 ? 84 : 60, animationDelay: `${i * 0.4}s`, marginBottom: i % 2 === 0 ? 0 : 20 }}>
            <img src={src} alt="" className="w-full h-full object-cover" loading="lazy" />
          </div>
        ))}
      </div>
      <div className="absolute -bottom-10 -right-6 text-[9rem] opacity-10 rotate-12 select-none">🐾</div>
      <div className="absolute -top-8 left-1/3 text-7xl opacity-10 -rotate-12 select-none">🐾</div>
    </div>
  );
}

function DashHead({ title, sub, action }) {
  return (
    <div className="flex flex-wrap items-end justify-between gap-4 mb-7">
      <div>
        <h2 className="fs-display text-2xl font-semibold">{title}</h2>
        {sub && <p className="fs-muted text-sm mt-1">{sub}</p>}
      </div>
      {action}
    </div>
  );
}

function StatCard({ icon: Icon, label, value, color, i = 0 }) {
  return (
    <AnimIn i={i} className="fs-card fs-card-hover p-5 flex items-center gap-4">
      <div className="w-12 h-12 rounded-2xl flex items-center justify-center shrink-0 fs-icon-pop" style={{ background: `var(--${color}-soft)` }}><Icon size={20} style={{ color: `var(--${color})` }} /></div>
      <div><div className="text-2xl font-semibold fs-display">{value}</div><div className="text-xs fs-muted font-medium">{label}</div></div>
    </AnimIn>
  );
}

/* ============================================================================
   OWNER DASHBOARD
============================================================================ */
function OwnerDashboard({ ctx }) {
  const { dashTab } = ctx;
  if (dashTab === "overview") return <OwnerOverview ctx={ctx} />;
  if (dashTab === "pets") return <OwnerPets ctx={ctx} />;
  if (dashTab === "health") return <OwnerHealth ctx={ctx} />;
  if (dashTab === "appointments") return <OwnerAppointments ctx={ctx} />;
  if (dashTab === "care") return <CareCenterTab ctx={ctx} />;
  if (dashTab === "shop") return <OwnerShop ctx={ctx} />;
  if (dashTab === "cart") return <OwnerCart ctx={ctx} />;
  return null;
}

function OwnerOverview({ ctx }) {
  const { user, pets, appts, records, setDashTab } = ctx;
  const myPets = pets.filter(p => p.ownerId === user.id);
  const myAppts = appts.filter(a => a.ownerId === user.id);
  const upcoming = myAppts.filter(a => a.status !== "Cancelled").slice(0, 3);
  const recentRecords = records.filter(r => myPets.some(p => p.id === r.petId)).slice(-3).reverse();
  return (
    <div>
      <DashBanner role="Pet Owner" gradient="linear-gradient(120deg,#7C4DFF,#FF6B9D)" photos={[PHOTOS.cat1, PHOTOS.dogLight]} tagline={`Welcome back, ${user.name.split(" ")[0]} — your pets are in great hands.`} />
      <DashHead title={`Hi, ${user.name.split(" ")[0]} 👋`} sub="Here's what's happening with your pets today." />
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <StatCard i={0} icon={PawPrint} label="My Pets" value={myPets.length} color="p1" />
        <StatCard i={1} icon={Calendar} label="Appointments" value={myAppts.length} color="p2" />
        <StatCard i={2} icon={FileText} label="Health Records" value={records.filter(r => myPets.some(p => p.id === r.petId)).length} color="p3" />
        <StatCard i={3} icon={ShoppingCart} label="Cart Items" value={ctx.cartCount} color="p4" />
      </div>
      <div className="grid lg:grid-cols-2 gap-5">
        <div className="fs-card p-6">
          <div className="flex items-center justify-between mb-4"><h3 className="font-semibold">Upcoming Appointments</h3><button onClick={() => setDashTab("appointments")} className="text-xs font-semibold" style={{ color: "var(--p1)" }}>View all</button></div>
          {upcoming.length === 0 && <p className="fs-muted text-sm">No appointments yet.</p>}
          <div className="space-y-3">
            {upcoming.map(a => {
              const pet = pets.find(p => p.id === a.petId);
              const vet = ctx.accounts.find(v => v.id === a.vetId);
              return (
                <div key={a.id} className="flex items-center gap-3 p-3 rounded-2xl" style={{ background: "var(--surface-2)" }}>
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: "var(--p1-soft)" }}><Calendar size={16} style={{ color: "var(--p1)" }} /></div>
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-medium truncate">{pet?.name} · {a.reason}</div>
                    <div className="text-xs fs-muted">{fmtDate(a.date)}, {a.time} · {vet?.name}</div>
                  </div>
                  <StatusPill status={a.status} />
                </div>
              );
            })}
          </div>
        </div>
        <div className="fs-card p-6">
          <div className="flex items-center justify-between mb-4"><h3 className="font-semibold">Recent Health Updates</h3><button onClick={() => setDashTab("health")} className="text-xs font-semibold" style={{ color: "var(--p1)" }}>View all</button></div>
          {recentRecords.length === 0 && <p className="fs-muted text-sm">No records yet.</p>}
          <div className="space-y-3">
            {recentRecords.map(r => {
              const pet = pets.find(p => p.id === r.petId);
              return (
                <div key={r.id} className="flex items-center gap-3 p-3 rounded-2xl" style={{ background: "var(--surface-2)" }}>
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: "var(--p3-soft)" }}><Syringe size={16} style={{ color: "var(--p3)" }} /></div>
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-medium truncate">{pet?.name} · {r.title}</div>
                    <div className="text-xs fs-muted">{r.type} · {fmtDate(r.date)}</div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}

function StatusPill({ status }) {
  const map = {
    Confirmed: "p4", Pending: "p3", Cancelled: "p2", Completed: "p1", Available: "p4",
    Adopted: "p1", New: "p3", Responded: "p4", Placed: "p4",
  };
  const c = map[status] || "p1";
  return <span className="fs-chip shrink-0" style={{ background: `var(--${c}-soft)`, color: `var(--${c})` }}>{status}</span>;
}

/* --- My Pets --- */
function OwnerPets({ ctx }) {
  const { user, pets, setPets, notify } = ctx;
  const myPets = pets.filter(p => p.ownerId === user.id);
  const [modal, setModal] = useState(null); // {mode:'add'|'edit', pet}
  const [active, setActive] = useState(myPets[0]?.id || null);
  const activePet = myPets.find(p => p.id === active) || myPets[0];

  const save = async (data) => {
    try {
      if (modal.mode === "add") {
        const pet = Backend.mapPet(await Backend.createPet(user.id, { ...data, images: [] }));
        setPets(prev => [...prev, pet]);
        setActive(pet.id);
        notify("Pet profile added.");
      } else {
        const pet = Backend.mapPet(await Backend.updatePet(modal.pet.id, data));
        setPets(prev => prev.map(p => p.id === modal.pet.id ? pet : p));
        notify("Pet profile updated.");
      }
    } catch (e) { notify(e.message || "Unable to save pet profile.", "error"); }
    setModal(null);
  };
  const remove = async (id) => {
    try {
      await Backend.deletePet(id);
      setPets(prev => prev.filter(p => p.id !== id));
      if (active === id) setActive(myPets.find(p => p.id !== id)?.id || null);
      notify("Pet profile deleted.");
    } catch (e) { notify(e.message || "Unable to delete pet profile.", "error"); }
  };

  return (
    <div>
      <DashHead title="My Pets" sub="Manage profiles for every pet in your care." action={
        <button onClick={() => setModal({ mode: "add" })} className="fs-btn-primary fs-focusable px-5 py-2.5 flex items-center gap-2 text-sm"><Plus size={16} /> Add Pet</button>
      } />
      {myPets.length === 0 ? (
        <EmptyState icon={PawPrint} title="No pets yet" desc="Add your first pet to start tracking their care." action={<button onClick={() => setModal({ mode: "add" })} className="fs-btn-primary fs-focusable px-5 py-2.5 text-sm">Add a Pet</button>} />
      ) : (
        <div className="grid lg:grid-cols-[240px_1fr] gap-6">
          <div className="flex lg:flex-col gap-2 overflow-x-auto fs-scroll pb-2 lg:pb-0">
            {myPets.map(p => {
              const Icon = speciesIcon(p.species);
              const photo = speciesPhoto(p.species, p.id);
              return (
                <button key={p.id} onClick={() => setActive(p.id)} className={`fs-focusable fs-tap shrink-0 lg:w-full flex items-center gap-3 px-4 py-3 rounded-2xl border fs-border text-left`}
                  style={active === p.id ? { background: "var(--p1-soft)", borderColor: "var(--p1)" } : { background: "var(--surface)" }}>
                  <div className="w-9 h-9 rounded-xl flex items-center justify-center shrink-0 overflow-hidden" style={{ background: "var(--grad)" }}>
                    {photo ? <img src={photo} alt="" className="w-full h-full object-cover" /> : <Icon size={16} color="#fff" />}
                  </div>
                  <div className="min-w-0"><div className="text-sm font-semibold truncate">{p.name}</div><div className="text-xs fs-muted truncate">{p.breed}</div></div>
                </button>
              );
            })}
          </div>
          {activePet && (
            <div className="fs-card fs-anim-in overflow-hidden">
              <div className="h-36 relative overflow-hidden">
                {speciesPhoto(activePet.species, activePet.id) ? (
                  <img src={speciesPhoto(activePet.species, activePet.id)} alt={activePet.name} className="w-full h-full object-cover" />
                ) : <div className="w-full h-full" style={{ background: "var(--grad)" }} />}
                <div className="absolute inset-0" style={{ background: "linear-gradient(180deg, transparent 40%, var(--surface) 100%)" }} />
              </div>
              <div className="p-7 pt-0 -mt-10 relative">
              <div className="flex flex-wrap items-start justify-between gap-4 mb-6">
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 rounded-3xl flex items-center justify-center text-3xl overflow-hidden border-4" style={{ background: "var(--surface-2)", borderColor: "var(--surface)" }}>
                    {speciesPhoto(activePet.species, activePet.id) ? <img src={speciesPhoto(activePet.species, activePet.id)} alt="" className="w-full h-full object-cover" /> : React.createElement(speciesIcon(activePet.species), { size: 30, style: { color: "var(--p1)" } })}
                  </div>
                  <div>
                    <h3 className="fs-display text-xl font-semibold">{activePet.name}</h3>
                    <p className="fs-muted text-sm">{activePet.breed} · {activePet.species}</p>
                  </div>
                </div>
                <div className="flex gap-2">
                  <button onClick={() => setModal({ mode: "edit", pet: activePet })} className="fs-btn-outline fs-focusable fs-tap w-9 h-9 !rounded-full flex items-center justify-center"><Pencil size={15} /></button>
                  <button onClick={() => remove(activePet.id)} className="fs-focusable fs-tap w-9 h-9 rounded-full flex items-center justify-center border fs-border" style={{ color: "var(--p2)" }}><Trash2 size={15} /></button>
                </div>
              </div>
              <div className="grid sm:grid-cols-3 gap-4 mb-6">
                <InfoTile label="Age" value={activePet.age} />
                <InfoTile label="Gender" value={activePet.gender} />
                <InfoTile label="Species" value={activePet.species} />
              </div>
              <div>
                <h4 className="text-sm font-semibold mb-2">Medical History Notes</h4>
                <p className="text-sm fs-muted p-4 rounded-2xl" style={{ background: "var(--surface-2)" }}>{activePet.notes || "No notes added yet."}</p>
              </div>
              <div className="mt-6">
                <h4 className="text-sm font-semibold mb-2 flex items-center gap-2"><Camera size={15} /> Image Gallery</h4>
                <div className="flex gap-3 flex-wrap">
                  {[0, 1].map(i => {
                    const g = speciesPhoto(activePet.species, activePet.id + i + 7);
                    return g ? (
                      <div key={i} className="w-20 h-20 rounded-2xl overflow-hidden fs-anim-pop" style={{ animationDelay: `${i * 80}ms` }}><img src={g} alt="" className="w-full h-full object-cover" loading="lazy" /></div>
                    ) : null;
                  })}
                  <div className="w-20 h-20 rounded-2xl flex items-center justify-center border-2 border-dashed fs-border fs-muted fs-tap cursor-pointer" style={{ background: "var(--surface-2)" }}><Upload size={16} /></div>
                </div>
              </div>
              </div>
            </div>
          )}
        </div>
      )}
      {modal && <PetModal modal={modal} onClose={() => setModal(null)} onSave={save} />}
    </div>
  );
}

function InfoTile({ label, value }) {
  return (
    <div className="p-4 rounded-2xl" style={{ background: "var(--surface-2)" }}>
      <div className="text-xs fs-muted mb-1">{label}</div>
      <div className="font-semibold text-sm">{value}</div>
    </div>
  );
}

function EmptyState({ icon: Icon, title, desc, action }) {
  return (
    <div className="fs-card p-14 text-center">
      <div className="w-16 h-16 rounded-3xl flex items-center justify-center mx-auto mb-4" style={{ background: "var(--p1-soft)" }}><Icon size={26} style={{ color: "var(--p1)" }} /></div>
      <h3 className="font-semibold text-lg mb-1.5">{title}</h3>
      <p className="fs-muted text-sm mb-6 max-w-sm mx-auto">{desc}</p>
      {action}
    </div>
  );
}

function Modal({ title, onClose, children, wide }) {
  return (
    <div className="fs-modal-backdrop fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/40" onClick={onClose}>
      <div onClick={e => e.stopPropagation()} className={`fs-card fs-modal-panel w-full ${wide ? "max-w-2xl" : "max-w-md"} max-h-[88vh] overflow-y-auto fs-scroll`} style={{ background: "var(--surface)" }}>
        <div className="flex items-center justify-between p-5 border-b fs-border sticky top-0" style={{ background: "var(--surface)" }}>
          <h3 className="font-semibold">{title}</h3>
          <button onClick={onClose} className="fs-focusable w-8 h-8 rounded-full flex items-center justify-center" style={{ background: "var(--surface-2)" }}><X size={16} /></button>
        </div>
        <div className="p-5">{children}</div>
      </div>
    </div>
  );
}

function PetModal({ modal, onClose, onSave }) {
  const p = modal.pet;
  const [f, setF] = useState({ name: p?.name || "", species: p?.species || "Dog", breed: p?.breed || "", age: p?.age || "", gender: p?.gender || "Male", notes: p?.notes || "" });
  return (
    <Modal title={modal.mode === "add" ? "Add Pet" : "Edit Pet"} onClose={onClose}>
      <form onSubmit={e => { e.preventDefault(); onSave(f); }} className="space-y-4">
        <div><label className="text-sm font-medium mb-1.5 block">Name</label><input required className="fs-input" value={f.name} onChange={e => setF({ ...f, name: e.target.value })} /></div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="text-sm font-medium mb-1.5 block">Species</label>
            <select className="fs-input" value={f.species} onChange={e => setF({ ...f, species: e.target.value })}>
              {["Dog", "Cat", "Bird", "Rabbit", "Fish"].map(s => <option key={s}>{s}</option>)}
            </select>
          </div>
          <div><label className="text-sm font-medium mb-1.5 block">Breed</label><input className="fs-input" value={f.breed} onChange={e => setF({ ...f, breed: e.target.value })} /></div>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div><label className="text-sm font-medium mb-1.5 block">Age</label><input className="fs-input" placeholder="e.g. 2 yrs" value={f.age} onChange={e => setF({ ...f, age: e.target.value })} /></div>
          <div>
            <label className="text-sm font-medium mb-1.5 block">Gender</label>
            <select className="fs-input" value={f.gender} onChange={e => setF({ ...f, gender: e.target.value })}><option>Male</option><option>Female</option></select>
          </div>
        </div>
        <div><label className="text-sm font-medium mb-1.5 block">Medical History Notes</label><textarea rows={3} className="fs-input resize-none" value={f.notes} onChange={e => setF({ ...f, notes: e.target.value })} /></div>
        <button className="fs-btn-primary fs-focusable w-full py-3">{modal.mode === "add" ? "Add Pet" : "Save Changes"}</button>
      </form>
    </Modal>
  );
}

/* --- Health Records --- */
function OwnerHealth({ ctx }) {
  const { user, pets, records, setRecords, notify } = ctx;
  const myPets = pets.filter(p => p.ownerId === user.id);
  const [petFilter, setPetFilter] = useState("All");
  const [modal, setModal] = useState(false);
  const list = records.filter(r => myPets.some(p => p.id === r.petId) && (petFilter === "All" || String(r.petId) === String(petFilter)))
    .sort((a, b) => new Date(b.date) - new Date(a.date));

  const add = async (data) => {
    try {
      const record = Backend.mapRecord(await Backend.createRecord({ type: data.type, title: data.title, date: data.date, notes: data.notes, vet_id: data.vetId || null, pet_id: data.petId }));
      setRecords(prev => [...prev, record]);
      notify("Health record added.");
      setModal(false);
    } catch (e) { notify(e.message || "Unable to add health record.", "error"); }
  };

  const typeIcon = { Vaccination: Syringe, Allergy: AlertCircle, Illness: Activity, Treatment: Stethoscope, Milestone: Star };

  return (
    <div>
      <DashHead title="Health Records" sub="Vaccinations, allergies, illnesses and treatments — all in one timeline." action={
        <button onClick={() => setModal(true)} className="fs-btn-primary fs-focusable px-5 py-2.5 flex items-center gap-2 text-sm"><Plus size={16} /> Add Record</button>
      } />
      <div className="flex flex-wrap gap-2 mb-6">
        <button onClick={() => setPetFilter("All")} className="fs-chip fs-focusable border fs-border" style={petFilter === "All" ? { background: "var(--p1)", color: "#fff" } : {}}>All Pets</button>
        {myPets.map(p => <button key={p.id} onClick={() => setPetFilter(String(p.id))} className="fs-chip fs-focusable border fs-border" style={petFilter === String(p.id) ? { background: "var(--p1)", color: "#fff" } : {}}>{p.name}</button>)}
      </div>

      {list.length === 0 ? <EmptyState icon={FileText} title="No records" desc="Track vaccinations, treatments and more here." action={<button onClick={() => setModal(true)} className="fs-btn-primary fs-focusable px-5 py-2.5 text-sm">Add Record</button>} /> : (
        <div className="relative pl-8">
          <div className="absolute left-[13px] top-2 bottom-2 w-0.5" style={{ background: "var(--border)" }} />
          <div className="space-y-5">
            {list.map((r, i) => {
              const pet = pets.find(p => p.id === r.petId);
              const Icon = typeIcon[r.type] || FileText;
              return (
                <AnimIn i={i} key={r.id} as="div" className="relative" style={{ animationName: "fsSlideRight" }}>
                  <div className="absolute -left-8 top-1 w-7 h-7 rounded-full flex items-center justify-center border-2 fs-anim-pop" style={{ background: "var(--surface)", borderColor: "var(--p1)", animationDelay: `${Math.min(i, 10) * 55 + 100}ms` }}>
                    <Icon size={13} style={{ color: "var(--p1)" }} />
                  </div>
                  <div className="fs-card fs-card-hover p-5">
                    <div className="flex flex-wrap items-center justify-between gap-2 mb-1.5">
                      <span className="font-semibold text-sm">{r.title}</span>
                      <span className="fs-chip" style={{ background: "var(--p1-soft)", color: "var(--p1)" }}>{r.type}</span>
                    </div>
                    <div className="text-xs fs-muted mb-2">{pet?.name} · {fmtDate(r.date)}</div>
                    <p className="text-sm fs-muted">{r.notes}</p>
                  </div>
                </AnimIn>
              );
            })}
          </div>
        </div>
      )}
      {modal && <HealthModal pets={myPets} onClose={() => setModal(false)} onSave={add} />}
    </div>
  );
}

function HealthModal({ pets, onClose, onSave }) {
  const [f, setF] = useState({ petId: pets[0]?.id, type: "Vaccination", title: "", date: new Date().toISOString().slice(0, 10), notes: "" });
  return (
    <Modal title="Add Health Record" onClose={onClose}>
      <form onSubmit={e => { e.preventDefault(); onSave({ ...f, petId: Number(f.petId) }); }} className="space-y-4">
        <div>
          <label className="text-sm font-medium mb-1.5 block">Pet</label>
          <select className="fs-input" value={f.petId} onChange={e => setF({ ...f, petId: e.target.value })}>{pets.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}</select>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="text-sm font-medium mb-1.5 block">Type</label>
            <select className="fs-input" value={f.type} onChange={e => setF({ ...f, type: e.target.value })}>{["Vaccination", "Allergy", "Illness", "Treatment", "Milestone"].map(t => <option key={t}>{t}</option>)}</select>
          </div>
          <div><label className="text-sm font-medium mb-1.5 block">Date</label><input type="date" className="fs-input" value={f.date} onChange={e => setF({ ...f, date: e.target.value })} /></div>
        </div>
        <div><label className="text-sm font-medium mb-1.5 block">Title</label><input required className="fs-input" placeholder="e.g. Rabies Booster" value={f.title} onChange={e => setF({ ...f, title: e.target.value })} /></div>
        <div><label className="text-sm font-medium mb-1.5 block">Notes</label><textarea rows={3} className="fs-input resize-none" value={f.notes} onChange={e => setF({ ...f, notes: e.target.value })} /></div>
        <div>
          <label className="text-sm font-medium mb-1.5 block">Attach file (certificate / X-ray / lab report)</label>
          <div className="border-2 border-dashed fs-border rounded-2xl p-6 text-center fs-muted text-sm"><Upload size={18} className="mx-auto mb-2" /> Click or drag file to upload</div>
        </div>
        <button className="fs-btn-primary fs-focusable w-full py-3">Save Record</button>
      </form>
    </Modal>
  );
}

/* --- Appointments (Owner) --- */
function OwnerAppointments({ ctx }) {
  const { user, pets, appts, setAppts, accounts, notify } = ctx;
  const myPets = pets.filter(p => p.ownerId === user.id);
  const myAppts = appts.filter(a => a.ownerId === user.id).sort((a, b) => new Date(a.date) - new Date(b.date));
  const vets = accounts.filter(a => a.role === "vet");
  const [modal, setModal] = useState(false);

  const book = async (data) => {
    try {
      const appt = Backend.mapAppt(await Backend.createAppointment({ date: data.date, time: data.time, reason: data.reason, owner_id: user.id, pet_id: data.petId, vet_id: data.vetId, status: "Pending" }));
      setAppts(prev => [...prev, appt]);
      notify("Appointment requested — awaiting vet confirmation.");
      setModal(false);
    } catch (e) { notify(e.message || "Unable to book appointment.", "error"); }
  };
  const cancel = async (id) => {
    try { const appt = Backend.mapAppt(await Backend.updateStatus(id, "Cancelled")); setAppts(prev => prev.map(a => a.id === id ? appt : a)); notify("Appointment cancelled."); }
    catch (e) { notify(e.message || "Unable to cancel appointment.", "error"); }
  };

  return (
    <div>
      <DashHead title="Appointments" sub="Book, track and manage vet visits for your pets." action={
        <button disabled={myPets.length === 0} onClick={() => setModal(true)} className="fs-btn-primary fs-focusable px-5 py-2.5 flex items-center gap-2 text-sm disabled:opacity-50"><Plus size={16} /> Book Appointment</button>
      } />
      <div className="mb-8">
        <h4 className="text-sm font-semibold mb-3">Recommended Veterinarians</h4>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {vets.map(v => (
            <div key={v.id} className="fs-card p-5">
              <div className="flex items-center gap-3 mb-2">
                <div className="w-10 h-10 rounded-xl flex items-center justify-center text-lg" style={{ background: "var(--grad)" }}>👩‍⚕️</div>
                <div><div className="font-semibold text-sm">{v.name}</div><div className="text-xs fs-muted">{v.specialization}</div></div>
              </div>
              <div className="flex items-center gap-1 text-xs mb-1"><MapPin size={12} className="fs-muted" /> <span className="fs-muted">{v.address}</span></div>
              <div className="flex items-center gap-1 text-xs"><Clock size={12} className="fs-muted" /> <span className="fs-muted">{v.experience}</span></div>
            </div>
          ))}
        </div>
      </div>
      {myAppts.length === 0 ? <EmptyState icon={Calendar} title="No appointments" desc="Book your pet's first vet visit." action={<button onClick={() => setModal(true)} className="fs-btn-primary fs-focusable px-5 py-2.5 text-sm">Book Appointment</button>} /> : (
        <div className="space-y-3">
          {myAppts.map((a, i) => {
            const pet = pets.find(p => p.id === a.petId);
            const vet = vets.find(v => v.id === a.vetId);
            return (
              <AnimIn i={i} key={a.id} className="fs-card fs-card-hover p-5 flex flex-wrap items-center gap-4 justify-between">
                <div className="flex items-center gap-4">
                  <div className="w-11 h-11 rounded-2xl flex items-center justify-center fs-icon-pop" style={{ background: "var(--p1-soft)" }}><Calendar size={18} style={{ color: "var(--p1)" }} /></div>
                  <div>
                    <div className="font-semibold text-sm">{pet?.name} · {a.reason}</div>
                    <div className="text-xs fs-muted">{fmtDate(a.date)} at {a.time} · {vet?.name}</div>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <StatusPill status={a.status} />
                  {a.status !== "Cancelled" && a.status !== "Completed" && <button onClick={() => cancel(a.id)} className="fs-focusable text-xs font-semibold" style={{ color: "var(--p2)" }}>Cancel</button>}
                </div>
              </AnimIn>
            );
          })}
        </div>
      )}
      {modal && <BookApptModal pets={myPets} vets={vets} onClose={() => setModal(false)} onSave={book} />}
    </div>
  );
}

function BookApptModal({ pets, vets, onClose, onSave }) {
  const [f, setF] = useState({ petId: pets[0]?.id, vetId: vets[0]?.id, date: "", time: vets[0]?.slots?.[0] || "10:00 AM", reason: "" });
  return (
    <Modal title="Book Appointment" onClose={onClose}>
      <form onSubmit={e => { e.preventDefault(); onSave({ ...f, petId: Number(f.petId), vetId: Number(f.vetId) }); }} className="space-y-4">
        <div>
          <label className="text-sm font-medium mb-1.5 block">Pet</label>
          <select className="fs-input" value={f.petId} onChange={e => setF({ ...f, petId: e.target.value })}>{pets.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}</select>
        </div>
        <div>
          <label className="text-sm font-medium mb-1.5 block">Veterinarian</label>
          <select className="fs-input" value={f.vetId} onChange={e => setF({ ...f, vetId: e.target.value })}>{vets.map(v => <option key={v.id} value={v.id}>{v.name} — {v.specialization}</option>)}</select>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div><label className="text-sm font-medium mb-1.5 block">Date</label><input required type="date" className="fs-input" value={f.date} onChange={e => setF({ ...f, date: e.target.value })} /></div>
          <div>
            <label className="text-sm font-medium mb-1.5 block">Time Slot</label>
            <select className="fs-input" value={f.time} onChange={e => setF({ ...f, time: e.target.value })}>
              {(vets.find(v => v.id === Number(f.vetId))?.slots || ["10:00 AM"]).map(s => <option key={s}>{s}</option>)}
            </select>
          </div>
        </div>
        <div><label className="text-sm font-medium mb-1.5 block">Reason for visit</label><input required className="fs-input" placeholder="e.g. Annual checkup" value={f.reason} onChange={e => setF({ ...f, reason: e.target.value })} /></div>
        <button className="fs-btn-primary fs-focusable w-full py-3">Request Appointment</button>
      </form>
    </Modal>
  );
}

/* --- Care Center --- */
function CareCenterTab({ ctx }) {
  const [cat, setCat] = useState("All");
  const cats = ["All", "Feeding", "Hygiene", "Exercise"];
  const filtered = CARE_ARTICLES.filter(a => cat === "All" || a.cat === cat);
  const [chat, setChat] = useState([{ from: "bot", text: "Hi! I'm the FurShield care assistant. Ask me about feeding, grooming or exercise. 🐾" }]);
  const [msg, setMsg] = useState("");

  const send = () => {
    if (!msg.trim()) return;
    const userMsg = { from: "user", text: msg };
    const reply = { from: "bot", text: "Great question! For personalized advice, book a quick consult with one of our vets — but generally, consistency and gentle routines work best for most pets." };
    setChat(prev => [...prev, userMsg, reply]);
    setMsg("");
  };

  return (
    <div>
      <DashHead title="Care Center" sub="Feeding, hygiene and exercise guidance — plus an AI assistant for quick questions." />
      <div className="grid lg:grid-cols-[1fr_320px] gap-6">
        <div>
          <div className="flex gap-2 mb-5">{cats.map(c => <button key={c} onClick={() => setCat(c)} className="fs-chip fs-focusable border fs-border" style={cat === c ? { background: "var(--p1)", color: "#fff" } : {}}>{c}</button>)}</div>
          <div className="grid sm:grid-cols-2 gap-4 mb-6">
            {filtered.map(a => (
              <div key={a.id} className="fs-card p-5">
                <span className="fs-chip inline-block mb-2" style={{ background: "var(--p1-soft)", color: "var(--p1)" }}>{a.cat}</span>
                <h4 className="font-semibold text-sm mb-1">{a.title}</h4>
                <p className="fs-muted text-xs">{a.desc}</p>
              </div>
            ))}
          </div>
          <div className="fs-card p-5">
            <h4 className="font-semibold text-sm mb-3">Frequently Asked Questions</h4>
            {[["How often should I bathe my dog?", "Every 4–6 weeks for most breeds, unless they get visibly dirty."], ["My cat won't eat — should I worry?", "Skipping one meal is normal; beyond 24 hours, consult a vet."]].map(([q, a], i) => (
              <details key={i} className="border-b fs-border py-3 last:border-0">
                <summary className="text-sm font-medium cursor-pointer">{q}</summary>
                <p className="text-xs fs-muted mt-2">{a}</p>
              </details>
            ))}
          </div>
        </div>
        <div className="fs-card p-5 flex flex-col h-[460px]">
          <div className="flex items-center gap-2 mb-3 font-semibold text-sm"><Sparkles size={15} style={{ color: "var(--p1)" }} /> AI Care Assistant</div>
          <div className="flex-1 overflow-y-auto fs-scroll space-y-2 mb-3">
            {chat.map((c, i) => (
              <div key={i} className={`text-sm p-3 rounded-2xl max-w-[85%] ${c.from === "user" ? "ml-auto" : ""}`} style={{ background: c.from === "user" ? "var(--grad)" : "var(--surface-2)", color: c.from === "user" ? "#fff" : "var(--text)" }}>{c.text}</div>
            ))}
          </div>
          <div className="flex gap-2">
            <input value={msg} onChange={e => setMsg(e.target.value)} onKeyDown={e => e.key === "Enter" && send()} placeholder="Ask about care..." className="fs-input" />
            <button onClick={send} className="fs-btn-primary fs-focusable px-4"><ArrowRight size={16} /></button>
          </div>
        </div>
      </div>
    </div>
  );
}

/* --- Shop (Owner) --- */
function OwnerShop({ ctx }) {
  const { products, addToCart } = ctx;
  const [cat, setCat] = useState("All");
  const [q, setQ] = useState("");
  const cats = ["All", ...new Set(products.map(p => p.category))];
  const filtered = products.filter(p => (cat === "All" || p.category === cat) && p.name.toLowerCase().includes(q.toLowerCase()));
  return (
    <div>
      <DashHead title="Shop" sub="Add food, grooming, toys and more to your cart." />
      <div className="flex flex-wrap gap-3 items-center justify-between mb-6">
        <div className="flex flex-wrap gap-2">{cats.map(c => <button key={c} onClick={() => setCat(c)} className="fs-chip fs-focusable border fs-border" style={cat === c ? { background: "var(--p1)", color: "#fff" } : {}}>{c}</button>)}</div>
        <div className="relative w-full sm:w-60">
          <Search size={14} className="absolute left-3.5 top-1/2 -translate-y-1/2 fs-muted" />
          <input value={q} onChange={e => setQ(e.target.value)} placeholder="Search..." className="fs-input pl-9 text-sm" />
        </div>
      </div>
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
        {filtered.map((p, i) => <ProductCard key={p.id} p={p} i={i} onAdd={() => addToCart(p.id)} />)}
      </div>
    </div>
  );
}

/* --- Cart & Orders --- */
function OwnerCart({ ctx }) {
  const { products, cart, setCartQty, removeFromCart, cartTotal, checkout, orders, user } = ctx;
  const myOrders = orders.filter(o => o.ownerId === user.id);
  return (
    <div>
      <DashHead title="Cart & Orders" sub="Review your cart and past orders." />
      <div className="grid lg:grid-cols-[1fr_320px] gap-6 mb-10">
        <div className="fs-card p-5">
          <h4 className="font-semibold mb-4">Your Cart</h4>
          {cart.length === 0 ? <p className="fs-muted text-sm py-6 text-center">Your cart is empty.</p> : (
            <div className="space-y-3">
              {cart.map(c => {
                const p = products.find(p => p.id === c.productId);
                if (!p) return null;
                return (
                  <div key={c.productId} className="flex items-center gap-3 p-3 rounded-2xl" style={{ background: "var(--surface-2)" }}>
                    <div className="w-12 h-12 rounded-xl flex items-center justify-center text-2xl shrink-0" style={{ background: "var(--surface)" }}>{p.icon}</div>
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-medium truncate">{p.name}</div>
                      <div className="text-xs fs-muted">{fmtMoney(p.price)} each</div>
                    </div>
                    <div className="flex items-center gap-2 border fs-border rounded-full px-1">
                      <button onClick={() => setCartQty(c.productId, c.qty - 1)} className="w-6 h-6 flex items-center justify-center fs-focusable">−</button>
                      <span className="text-sm w-5 text-center">{c.qty}</span>
                      <button onClick={() => setCartQty(c.productId, c.qty + 1)} className="w-6 h-6 flex items-center justify-center fs-focusable">+</button>
                    </div>
                    <button onClick={() => removeFromCart(c.productId)} className="fs-focusable" style={{ color: "var(--p2)" }}><Trash2 size={15} /></button>
                  </div>
                );
              })}
            </div>
          )}
        </div>
        <div className="fs-card p-5 h-fit">
          <h4 className="font-semibold mb-4">Order Summary</h4>
          <div className="flex justify-between text-sm mb-2 fs-muted"><span>Subtotal</span><span>{fmtMoney(cartTotal)}</span></div>
          <div className="flex justify-between text-sm mb-4 fs-muted"><span>Delivery</span><span>Not included</span></div>
          <div className="flex justify-between font-semibold mb-5 border-t fs-border pt-3"><span>Total</span><span>{fmtMoney(cartTotal)}</span></div>
          <button disabled={cart.length === 0} onClick={checkout} className="fs-btn-primary fs-focusable w-full py-3 disabled:opacity-50">Place Order</button>
          <p className="text-[11px] fs-muted mt-2 text-center">No payment gateway per project scope.</p>
        </div>
      </div>
      <h4 className="font-semibold mb-4">Order History</h4>
      {myOrders.length === 0 ? <p className="fs-muted text-sm">No orders placed yet.</p> : (
        <div className="space-y-3">
          {myOrders.map(o => (
            <div key={o.id} className="fs-card p-5 flex flex-wrap items-center justify-between gap-3">
              <div>
                <div className="text-sm font-semibold">Order #{o.id}</div>
                <div className="text-xs fs-muted">{new Date(o.date).toLocaleString()} · {o.items.reduce((s, i) => s + i.qty, 0)} items</div>
              </div>
              <div className="flex items-center gap-4">
                <span className="font-semibold text-sm">{fmtMoney(o.total)}</span>
                <StatusPill status={o.status} />
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

/* ============================================================================
   VET DASHBOARD
============================================================================ */
function VetDashboard({ ctx }) {
  const { dashTab } = ctx;
  if (dashTab === "overview") return <VetOverview ctx={ctx} />;
  if (dashTab === "profile") return <VetProfile ctx={ctx} />;
  if (dashTab === "appointments") return <VetAppointments ctx={ctx} />;
  if (dashTab === "logs") return <VetLogs ctx={ctx} />;
  return null;
}

function VetOverview({ ctx }) {
  const { user, appts, pets, setDashTab } = ctx;
  const myAppts = appts.filter(a => a.vetId === user.id);
  const pending = myAppts.filter(a => a.status === "Pending").length;
  const confirmed = myAppts.filter(a => a.status === "Confirmed").length;
  const upcoming = myAppts.filter(a => a.status !== "Cancelled").sort((a, b) => new Date(a.date) - new Date(b.date)).slice(0, 4);
  return (
    <div>
      <DashBanner role="Veterinarian" gradient="linear-gradient(120deg,#2563EB,#17B897)" photos={[PHOTOS.dogGroup, PHOTOS.vetDog]} tagline={`Good to see you, ${user.name.split(" ")[1] || user.name} — your patients are waiting.`} />
      <DashHead title={`Welcome, ${user.name} 👋`} sub={`${user.specialization || "General Practice"} · ${user.experience || ""}`} />
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <StatCard i={0} icon={Calendar} label="Total Appointments" value={myAppts.length} color="p1" />
        <StatCard i={1} icon={Clock} label="Pending Approval" value={pending} color="p3" />
        <StatCard i={2} icon={CheckCircle2} label="Confirmed" value={confirmed} color="p4" />
        <StatCard i={3} icon={ClipboardList} label="Available Slots" value={(user.slots || []).length} color="p2" />
      </div>
      <div className="fs-card p-6">
        <div className="flex items-center justify-between mb-4"><h3 className="font-semibold">Upcoming Appointments</h3><button onClick={() => setDashTab("appointments")} className="text-xs font-semibold" style={{ color: "var(--p1)" }}>Manage all</button></div>
        {upcoming.length === 0 && <p className="fs-muted text-sm">No appointments scheduled.</p>}
        <div className="space-y-3">
          {upcoming.map(a => {
            const pet = pets.find(p => p.id === a.petId);
            return (
              <div key={a.id} className="flex items-center gap-3 p-3 rounded-2xl" style={{ background: "var(--surface-2)" }}>
                <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: "var(--p1-soft)" }}>{React.createElement(speciesIcon(pet?.species), { size: 16, style: { color: "var(--p1)" } })}</div>
                <div className="flex-1 min-w-0"><div className="text-sm font-medium truncate">{pet?.name} · {a.reason}</div><div className="text-xs fs-muted">{fmtDate(a.date)}, {a.time}</div></div>
                <StatusPill status={a.status} />
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

function VetProfile({ ctx }) {
  const { user, accounts, setAccounts, notify } = ctx;
  const [f, setF] = useState({ specialization: user.specialization || "", experience: user.experience || "", bio: user.bio || "", slots: (user.slots || []).join(", ") });
  const save = async (e) => {
    e.preventDefault();
    try {
      const updated = await Backend.updateProfile(user.id, { specialization: f.specialization, experience: f.experience, bio: f.bio, slots: f.slots.split(",").map(s => s.trim()).filter(Boolean) });
      setAccounts(prev => prev.map(a => a.id === user.id ? updated : a));
      notify("Profile updated.");
    } catch (err) { notify(err.message || "Unable to update profile.", "error"); }
  };
  return (
    <div>
      <DashHead title="My Profile" sub="Enhance your public profile with specialization and availability." />
      <div className="grid lg:grid-cols-[1fr_320px] gap-6">
        <form onSubmit={save} className="fs-card p-6 space-y-4">
          <div className="grid sm:grid-cols-2 gap-4">
            <div><label className="text-sm font-medium mb-1.5 block">Specialization</label><input className="fs-input" value={f.specialization} onChange={e => setF({ ...f, specialization: e.target.value })} /></div>
            <div><label className="text-sm font-medium mb-1.5 block">Experience</label><input className="fs-input" value={f.experience} onChange={e => setF({ ...f, experience: e.target.value })} /></div>
          </div>
          <div><label className="text-sm font-medium mb-1.5 block">Bio</label><textarea rows={3} className="fs-input resize-none" value={f.bio} onChange={e => setF({ ...f, bio: e.target.value })} /></div>
          <div><label className="text-sm font-medium mb-1.5 block">Available Time Slots (comma separated)</label><input className="fs-input" placeholder="Mon 10:00 AM, Wed 2:00 PM" value={f.slots} onChange={e => setF({ ...f, slots: e.target.value })} /></div>
          <button className="fs-btn-primary fs-focusable px-6 py-3">Save Profile</button>
        </form>
        <div className="fs-card p-6 text-center">
          <div className="w-16 h-16 mx-auto rounded-3xl flex items-center justify-center text-3xl mb-3" style={{ background: "var(--grad)" }}>👩‍⚕️</div>
          <h4 className="font-semibold">{user.name}</h4>
          <p className="text-xs fs-muted mb-3">{user.email}</p>
          <div className="text-left space-y-2 text-sm">
            <div className="flex items-center gap-2 fs-muted"><Phone size={13} /> {user.phone}</div>
            <div className="flex items-center gap-2 fs-muted"><MapPin size={13} /> {user.address}</div>
          </div>
        </div>
      </div>
    </div>
  );
}

function VetAppointments({ ctx }) {
  const { user, appts, setAppts, pets, accounts, notify } = ctx;
  const myAppts = appts.filter(a => a.vetId === user.id).sort((a, b) => new Date(a.date) - new Date(b.date));
  const setStatus = async (id, status) => {
    try { const appt = Backend.mapAppt(await Backend.updateStatus(id, status)); setAppts(prev => prev.map(a => a.id === id ? appt : a)); notify(`Appointment ${status.toLowerCase()}.`); }
    catch (e) { notify(e.message || "Unable to update appointment.", "error"); }
  };
  return (
    <div>
      <DashHead title="Manage Appointments" sub="Approve, reschedule and track bookings." />
      {myAppts.length === 0 ? <EmptyState icon={Calendar} title="No appointments" desc="Bookings from pet owners will appear here." /> : (
        <div className="space-y-3">
          {myAppts.map(a => {
            const pet = pets.find(p => p.id === a.petId);
            const owner = accounts.find(o => o.id === a.ownerId);
            return (
              <div key={a.id} className="fs-card p-5 flex flex-wrap items-center gap-4 justify-between">
                <div className="flex items-center gap-4">
                  <div className="w-11 h-11 rounded-2xl flex items-center justify-center" style={{ background: "var(--p1-soft)" }}>{React.createElement(speciesIcon(pet?.species), { size: 18, style: { color: "var(--p1)" } })}</div>
                  <div>
                    <div className="font-semibold text-sm">{pet?.name} ({pet?.species}) · {a.reason}</div>
                    <div className="text-xs fs-muted">{fmtDate(a.date)} at {a.time} · Owner: {owner?.name}</div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <StatusPill status={a.status} />
                  {a.status === "Pending" && <button onClick={() => setStatus(a.id, "Confirmed")} className="fs-btn-primary fs-focusable px-3.5 py-1.5 text-xs">Approve</button>}
                  {a.status !== "Cancelled" && a.status !== "Completed" && <button onClick={() => setStatus(a.id, "Completed")} className="fs-btn-outline fs-focusable px-3.5 py-1.5 text-xs">Mark Done</button>}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

function VetLogs({ ctx }) {
  const { user, appts, pets, records, setRecords, accounts, notify } = ctx;
  const myPatients = [...new Map(appts.filter(a => a.vetId === user.id).map(a => [a.petId, pets.find(p => p.id === a.petId)])).values()].filter(Boolean);
  const [selected, setSelected] = useState(myPatients[0]?.id || null);
  const [modal, setModal] = useState(false);
  const pet = myPatients.find(p => p.id === selected);
  const petRecords = records.filter(r => r.petId === selected).sort((a, b) => new Date(b.date) - new Date(a.date));

  const addLog = async (data) => {
    try {
      const record = Backend.mapRecord(await Backend.createRecord({ type: data.type, title: data.title, date: data.date, notes: data.notes, pet_id: selected, vet_id: user.id }));
      setRecords(prev => [...prev, record]);
      notify("Treatment note logged.");
      setModal(false);
    } catch (e) { notify(e.message || "Unable to log treatment.", "error"); }
  };

  return (
    <div>
      <DashHead title="Medical Logs" sub="View history and log diagnosis, treatment and follow-ups for your patients." />
      {myPatients.length === 0 ? <EmptyState icon={ClipboardList} title="No patients yet" desc="Patients appear once an owner books an appointment with you." /> : (
        <div className="grid lg:grid-cols-[220px_1fr] gap-6">
          <div className="flex lg:flex-col gap-2 overflow-x-auto fs-scroll">
            {myPatients.map(p => (
              <button key={p.id} onClick={() => setSelected(p.id)} className="fs-focusable shrink-0 lg:w-full flex items-center gap-3 px-4 py-3 rounded-2xl border fs-border text-left" style={selected === p.id ? { background: "var(--p1-soft)", borderColor: "var(--p1)" } : { background: "var(--surface)" }}>
                {React.createElement(speciesIcon(p.species), { size: 16, style: { color: "var(--p1)" } })}
                <span className="text-sm font-semibold">{p.name}</span>
              </button>
            ))}
          </div>
          <div>
            <div className="flex items-center justify-between mb-4">
              <h4 className="font-semibold">{pet?.name}'s Records</h4>
              <button onClick={() => setModal(true)} className="fs-btn-primary fs-focusable px-4 py-2 text-xs flex items-center gap-1.5"><Plus size={14} /> Log Treatment</button>
            </div>
            <div className="space-y-3">
              {petRecords.length === 0 && <p className="fs-muted text-sm">No records for this pet yet.</p>}
              {petRecords.map(r => (
                <div key={r.id} className="fs-card p-5">
                  <div className="grid sm:grid-cols-2 gap-3 text-xs mb-2">
                    <div><span className="fs-muted">Symptoms / Type: </span><span className="font-medium">{r.type}</span></div>
                    <div><span className="fs-muted">Date: </span><span className="font-medium">{fmtDate(r.date)}</span></div>
                  </div>
                  <div className="font-semibold text-sm mb-1">{r.title}</div>
                  <p className="text-sm fs-muted">{r.notes}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
      {modal && <HealthModal pets={[pet]} onClose={() => setModal(false)} onSave={addLog} />}
    </div>
  );
}

/* ============================================================================
   SHELTER DASHBOARD
============================================================================ */
function ShelterDashboard({ ctx }) {
  const { dashTab } = ctx;
  if (dashTab === "overview") return <ShelterOverview ctx={ctx} />;
  if (dashTab === "listings") return <ShelterListings ctx={ctx} />;
  if (dashTab === "carelogs") return <ShelterCareLogs ctx={ctx} />;
  if (dashTab === "queries") return <ShelterQueries ctx={ctx} />;
  return null;
}

function ShelterOverview({ ctx }) {
  const { user, listings, queries, setDashTab } = ctx;
  const mine = listings.filter(l => l.shelterId === user.id);
  const available = mine.filter(l => l.status === "Available").length;
  const newQueries = queries.filter(q => mine.some(l => l.id === q.listingId) && q.status === "New").length;
  return (
    <div>
      <DashBanner role="Shelter" gradient="linear-gradient(120deg,#F59E0B,#17B897)" photos={[PHOTOS.rabbit1, PHOTOS.bird1]} tagline={`${user.name} — every listing here is a step closer to a forever home.`} />
      <DashHead title={`Welcome, ${user.name} 👋`} sub="Manage your adoptable pets and adopter interest." />
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <StatCard i={0} icon={PawPrint} label="Listed Pets" value={mine.length} color="p1" />
        <StatCard i={1} icon={Heart} label="Available" value={available} color="p4" />
        <StatCard i={2} icon={MessageSquare} label="New Queries" value={newQueries} color="p3" />
        <StatCard i={3} icon={BadgeCheck} label="Adopted" value={mine.filter(l => l.status === "Adopted").length} color="p2" />
      </div>
      <div className="fs-card p-6">
        <div className="flex items-center justify-between mb-4"><h3 className="font-semibold">Recent Listings</h3><button onClick={() => setDashTab("listings")} className="text-xs font-semibold" style={{ color: "var(--p1)" }}>Manage all</button></div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {mine.slice(0, 4).map(l => (
            <div key={l.id} className="rounded-2xl p-4 text-center" style={{ background: "var(--surface-2)" }}>
              <div className="text-4xl mb-2">{l.image}</div>
              <div className="text-sm font-semibold">{l.petName}</div>
              <StatusPill status={l.status} />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

const EMOJI_BY_SPECIES = { Dog: "🐕", Cat: "🐈", Rabbit: "🐇", Bird: "🦜", Fish: "🐠" };

function ShelterListings({ ctx }) {
  const { user, listings, setListings, notify } = ctx;
  const mine = listings.filter(l => l.shelterId === user.id);
  const [modal, setModal] = useState(null);

  const save = async (data) => {
    try {
      if (modal.mode === "add") {
        const l = Backend.mapListing(await Backend.createListing(user.id, { pet_name: data.petName, species: data.species, breed: data.breed, age: data.age, health: data.health, status: "Available", image: EMOJI_BY_SPECIES[data.species] || "🐾" }));
        setListings(prev => [...prev, l]);
        notify("Pet listed for adoption.");
      } else {
        const l = Backend.mapListing(await Backend.updateListing(modal.listing.id, { pet_name: data.petName, species: data.species, breed: data.breed, age: data.age, health: data.health, image: EMOJI_BY_SPECIES[data.species] || modal.listing.image }));
        setListings(prev => prev.map(x => x.id === l.id ? { ...x, ...l } : x));
        notify("Listing updated.");
      }
    } catch (e) { notify(e.message || "Unable to save listing.", "error"); }
    setModal(null);
  };
  const remove = async (id) => { try { await Backend.deleteListing(id); setListings(prev => prev.filter(l => l.id !== id)); notify("Listing removed."); } catch (e) { notify(e.message || "Unable to remove listing.", "error"); } };
  const setStatus = async (id, status) => { try { const l = Backend.mapListing(await Backend.updateListing(id, { status })); setListings(prev => prev.map(x => x.id === id ? { ...x, ...l } : x)); } catch (e) { notify(e.message || "Unable to update listing.", "error"); } };

  return (
    <div>
      <DashHead title="Adoptable Pets" sub="List and manage pets available for adoption." action={
        <button onClick={() => setModal({ mode: "add" })} className="fs-btn-primary fs-focusable px-5 py-2.5 flex items-center gap-2 text-sm"><Plus size={16} /> Add Listing</button>
      } />
      {mine.length === 0 ? <EmptyState icon={PawPrint} title="No listings yet" desc="Add your first adoptable pet." action={<button onClick={() => setModal({ mode: "add" })} className="fs-btn-primary fs-focusable px-5 py-2.5 text-sm">Add Listing</button>} /> : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {mine.map((l, i) => (
            <AnimIn i={i} key={l.id} className="fs-card fs-card-hover overflow-hidden">
              <div className="h-32 overflow-hidden" style={{ background: "var(--surface-2)" }}>
                <AdoptThumb species={l.species} seed={l.id} emoji={l.image} />
              </div>
              <div className="p-5">
                <div className="flex items-center justify-between mb-1"><h4 className="font-semibold">{l.petName}</h4><StatusPill status={l.status} /></div>
                <p className="text-xs fs-muted mb-3">{l.breed} · {l.age} · {l.health}</p>
                <div className="flex gap-2">
                  <select value={l.status} onChange={e => setStatus(l.id, e.target.value)} className="fs-input text-xs py-1.5 flex-1">
                    {["Available", "Pending", "Adopted"].map(s => <option key={s}>{s}</option>)}
                  </select>
                  <button onClick={() => setModal({ mode: "edit", listing: l })} className="fs-focusable w-8 h-8 rounded-full border fs-border flex items-center justify-center shrink-0"><Pencil size={13} /></button>
                  <button onClick={() => remove(l.id)} className="fs-focusable w-8 h-8 rounded-full border fs-border flex items-center justify-center shrink-0" style={{ color: "var(--p2)" }}><Trash2 size={13} /></button>
                </div>
              </div>
            </AnimIn>
          ))}
        </div>
      )}
      {modal && <ListingModal modal={modal} onClose={() => setModal(null)} onSave={save} />}
    </div>
  );
}

function ListingModal({ modal, onClose, onSave }) {
  const l = modal.listing;
  const [f, setF] = useState({ petName: l?.petName || "", species: l?.species || "Dog", breed: l?.breed || "", age: l?.age || "", health: l?.health || "" });
  return (
    <Modal title={modal.mode === "add" ? "Add Adoptable Pet" : "Edit Listing"} onClose={onClose}>
      <form onSubmit={e => { e.preventDefault(); onSave(f); }} className="space-y-4">
        <div><label className="text-sm font-medium mb-1.5 block">Pet Name</label><input required className="fs-input" value={f.petName} onChange={e => setF({ ...f, petName: e.target.value })} /></div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="text-sm font-medium mb-1.5 block">Species</label>
            <select className="fs-input" value={f.species} onChange={e => setF({ ...f, species: e.target.value })}>{["Dog", "Cat", "Rabbit", "Bird", "Fish"].map(s => <option key={s}>{s}</option>)}</select>
          </div>
          <div><label className="text-sm font-medium mb-1.5 block">Breed</label><input className="fs-input" value={f.breed} onChange={e => setF({ ...f, breed: e.target.value })} /></div>
        </div>
        <div><label className="text-sm font-medium mb-1.5 block">Age</label><input className="fs-input" placeholder="e.g. 8 months" value={f.age} onChange={e => setF({ ...f, age: e.target.value })} /></div>
        <div><label className="text-sm font-medium mb-1.5 block">Health Status</label><input className="fs-input" placeholder="e.g. Vaccinated, dewormed" value={f.health} onChange={e => setF({ ...f, health: e.target.value })} /></div>
        <button className="fs-btn-primary fs-focusable w-full py-3">{modal.mode === "add" ? "Add Listing" : "Save Changes"}</button>
      </form>
    </Modal>
  );
}

function ShelterCareLogs({ ctx }) {
  const { user, listings, setListings, notify } = ctx;
  const mine = listings.filter(l => l.shelterId === user.id);
  const [selected, setSelected] = useState(mine[0]?.id || null);
  const listing = mine.find(l => l.id === selected);
  const [form, setForm] = useState({ type: "Feeding", note: "" });

  const addLog = async (e) => {
    e.preventDefault();
    if (!form.note.trim()) return;
    try {
      const log = await Backend.addCareLog(selected, { type: form.type, note: form.note });
      setListings(prev => prev.map(l => l.id === selected ? { ...l, careLog: [log, ...(l.careLog || [])] } : l));
      setForm({ type: "Feeding", note: "" });
      notify("Care log updated.");
    } catch (err) { notify(err.message || "Unable to update care log.", "error"); }
  };

  return (
    <div>
      <DashHead title="Care Logs" sub="Track feeding, grooming and medical attention for each animal." />
      {mine.length === 0 ? <EmptyState icon={ClipboardCheck} title="No pets listed" desc="Add an adoptable pet first to start logging care." /> : (
        <div className="grid lg:grid-cols-[220px_1fr] gap-6">
          <div className="flex lg:flex-col gap-2 overflow-x-auto fs-scroll">
            {mine.map(l => (
              <button key={l.id} onClick={() => setSelected(l.id)} className="fs-focusable shrink-0 lg:w-full flex items-center gap-3 px-4 py-3 rounded-2xl border fs-border text-left" style={selected === l.id ? { background: "var(--p1-soft)", borderColor: "var(--p1)" } : { background: "var(--surface)" }}>
                <span className="text-lg">{l.image}</span><span className="text-sm font-semibold">{l.petName}</span>
              </button>
            ))}
          </div>
          {listing && (
            <div>
              <form onSubmit={addLog} className="fs-card p-5 flex flex-wrap gap-3 items-end mb-5">
                <div className="w-40">
                  <label className="text-xs font-medium mb-1.5 block">Type</label>
                  <select className="fs-input" value={form.type} onChange={e => setForm({ ...form, type: e.target.value })}>{["Feeding", "Grooming", "Medical"].map(t => <option key={t}>{t}</option>)}</select>
                </div>
                <div className="flex-1 min-w-[180px]">
                  <label className="text-xs font-medium mb-1.5 block">Note</label>
                  <input className="fs-input" placeholder="e.g. Fed twice today, good appetite" value={form.note} onChange={e => setForm({ ...form, note: e.target.value })} />
                </div>
                <button className="fs-btn-primary fs-focusable px-5 py-2.5 text-sm">Add Log</button>
              </form>
              <div className="space-y-3">
                {listing.careLog.length === 0 && <p className="fs-muted text-sm">No logs yet for {listing.petName}.</p>}
                {listing.careLog.map(log => (
                  <div key={log.id} className="fs-card p-4 flex items-center gap-3">
                    <span className="fs-chip" style={{ background: "var(--p1-soft)", color: "var(--p1)" }}>{log.type}</span>
                    <span className="text-sm flex-1">{log.note}</span>
                    <span className="text-xs fs-muted">{fmtDate(log.date)}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function ShelterQueries({ ctx }) {
  const { user, listings, queries, setQueries, notify } = ctx;
  const mine = listings.filter(l => l.shelterId === user.id);
  const myQueries = queries.filter(q => mine.some(l => l.id === q.listingId));
  const [replyOpen, setReplyOpen] = useState(null);
  const [reply, setReply] = useState("");

  const respond = async (id) => {
    try { await Backend.respondToQuery(id); setQueries(prev => prev.map(q => q.id === id ? { ...q, status: "Responded" } : q)); notify("Reply sent to adopter."); }
    catch (e) { notify(e.message || "Unable to respond.", "error"); }
    setReplyOpen(null); setReply("");
  };
  const finalize = async (id, listingId) => {
    try { await Backend.respondToQuery(id); setQueries(prev => prev.map(q => q.id === id ? { ...q, status: "Responded" } : q)); notify("Adoption status finalized."); }
    catch (e) { notify(e.message || "Unable to finalize adoption.", "error"); }
  };

  return (
    <div>
      <DashHead title="Adopter Queries" sub="Respond to interest forms and finalize adoptions." />
      {myQueries.length === 0 ? <EmptyState icon={MessageSquare} title="No queries yet" desc="Adopter messages will appear here." /> : (
        <div className="space-y-4">
          {myQueries.map(q => {
            const listing = listings.find(l => l.id === q.listingId);
            return (
              <div key={q.id} className="fs-card p-5">
                <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
                  <div className="flex items-center gap-3">
                    <span className="text-2xl">{listing?.image}</span>
                    <div><div className="font-semibold text-sm">{q.name} → {listing?.petName}</div><div className="text-xs fs-muted">{q.email}</div></div>
                  </div>
                  <StatusPill status={q.status} />
                </div>
                <p className="text-sm fs-muted mb-3 pl-11">{q.message}</p>
                <div className="flex gap-2 pl-11">
                  <button onClick={() => setReplyOpen(replyOpen === q.id ? null : q.id)} className="fs-btn-outline fs-focusable px-4 py-2 text-xs">Reply</button>
                  <button onClick={() => finalize(q.id, q.listingId)} className="fs-btn-primary fs-focusable px-4 py-2 text-xs">Mark Finalized</button>
                </div>
                {replyOpen === q.id && (
                  <div className="pl-11 mt-3 flex gap-2">
                    <input value={reply} onChange={e => setReply(e.target.value)} placeholder="Type a reply..." className="fs-input text-sm" />
                    <button onClick={() => respond(q.id)} className="fs-btn-primary fs-focusable px-4 text-sm">Send</button>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
