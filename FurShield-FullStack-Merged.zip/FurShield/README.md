# FurShield — Frontend + Supabase Backend (Merged)

The original FurShield frontend UI is kept intact. The Supabase backend/API layer is merged into the frontend project.

## Project structure

- `FurShield.jsx` — existing frontend UI
- `src/api/` — Supabase API modules
- `src/lib/supabaseClient.js` — Supabase client
- `supabase/migrations/0001_init_schema.sql` — database schema + RLS
- `supabase/seed.sql` — demo shop products
- `backendBridge.js` — frontend/backend integration layer
- `.env.example` — required Supabase environment variables

## Run

1. Create a Supabase project.
2. Run `supabase/migrations/0001_init_schema.sql` in Supabase SQL Editor.
3. Run `supabase/seed.sql`.
4. Copy `.env.example` to `.env` and set:
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_ANON_KEY`
5. Install dependencies:
   `npm install`
6. Start:
   `npm run dev`

No frontend visual redesign was made as part of the merge.
