import { supabase } from "./lib/supabaseClient";
import { listAllUsers, removeUserProfile, platformStats } from "./api/admin";
import { getCurrentUser, signIn, signUp, signOut, onAuthStateChange, updateProfile } from "./api/auth";
import { listMyPets, listAllPets, createPet, updatePet, deletePet } from "./api/pets";
import { listRecordsForPets, createRecord, deleteRecord } from "./api/records";
import { listByOwner, listByVet, listAll, createAppointment, updateStatus, deleteAppointment } from "./api/appointments";
import { listProducts, getCart, addToCart as apiAddToCart, setCartQty as apiSetCartQty, removeFromCart as apiRemoveFromCart, checkout as apiCheckout, listMyOrders } from "./api/shop";
import { listAllListings, listMyListings, createListing, updateListing, deleteListing, listCareLogs, addCareLog, listQueriesForListings, respondToQuery, submitQuery } from "./api/shelter";
import { listReviews, addReview, deleteReview, listNotifications, markRead, markAllRead, subscribeToNotifications } from "./api/reviewsAndNotifications";

export const mapProfile = p => p ? ({ ...p }) : null;
export const mapPet = p => ({ ...p, ownerId: p.owner_id, images: p.images || [] });
export const mapRecord = r => ({ ...r, petId: r.pet_id, vetId: r.vet_id });
export const mapAppt = a => ({ ...a, petId: a.pet_id, ownerId: a.owner_id, vetId: a.vet_id });
export const mapProduct = p => ({ ...p, desc: p.description || "", image: p.image || null });
export const mapCart = r => ({ id: r.id, productId: r.product_id, qty: r.qty, product: r.products });
export const mapOrder = o => ({ ...o, ownerId: o.owner_id, date: o.created_at, items: (o.order_items || []).map(i => ({ productId: i.product_id, qty: i.qty, unitPrice: i.unit_price })) });
export const mapListing = l => ({ ...l, shelterId: l.shelter_id, petName: l.pet_name, careLog: l.careLog || [], image: l.image || "🐾" });
export const mapQuery = q => ({ ...q, listingId: q.listing_id });
export const mapReview = r => ({ ...r });

export async function loadAppData(user) {
  const [products, listings, reviews] = await Promise.all([
    listProducts().catch(() => []),
    listAllListings().catch(() => []),
    listReviews().catch(() => [])
  ]);
  let accounts = [];
  let pets = [], records = [], appts = [], orders = [], cart = [], queries = [];
  if (user) {
    accounts = await listAllUsers().catch(() => []);
    if (user.role === "owner") {
      pets = (await listMyPets(user.id).catch(() => [])).map(mapPet);
      records = (await listRecordsForPets(pets.map(p => p.id)).catch(() => [])).map(mapRecord);
      appts = (await listByOwner(user.id).catch(() => [])).map(mapAppt);
      cart = (await getCart(user.id).catch(() => [])).map(mapCart);
      orders = (await listMyOrders(user.id).catch(() => [])).map(mapOrder);
    } else if (user.role === "vet") {
      pets = (await listAllPets().catch(() => [])).map(mapPet);
      records = (await listRecordsForPets(pets.map(p => p.id)).catch(() => [])).map(mapRecord);
      appts = (await listByVet(user.id).catch(() => [])).map(mapAppt);
    } else if (user.role === "shelter") {
      const mine = (await listMyListings(user.id).catch(() => [])).map(mapListing);
      const logs = await Promise.all(mine.map(l => listCareLogs(l.id).catch(() => [])));
      mine.forEach((l,i) => l.careLog = logs[i]);
      listings.splice(0, listings.length, ...mine, ...(await listAllListings().catch(() => [])).filter(x => x.shelter_id !== user.id).map(mapListing));
      queries = (await listQueriesForListings(mine.map(l => l.id)).catch(() => [])).map(mapQuery);
    } else if (user.role === "admin") {
      accounts = (await listAllUsers().catch(() => []));
      pets = (await listAllPets().catch(() => [])).map(mapPet);
      records = (await listRecordsForPets(pets.map(p => p.id)).catch(() => [])).map(mapRecord);
      appts = (await listAll().catch(() => [])).map(mapAppt);
    }
  }
  return { accounts, pets, records, appts, products: products.map(mapProduct), cart, orders, listings: listings.map(x => x.careLog ? x : mapListing(x)), queries, reviews: reviews.map(mapReview) };
}

export {
  getCurrentUser, signIn, signUp, signOut, onAuthStateChange, updateProfile,
  createPet, updatePet, deletePet, createRecord, deleteRecord, getCart,
  createAppointment, updateStatus, deleteAppointment,
  apiAddToCart, apiSetCartQty, apiRemoveFromCart, apiCheckout,
  createListing, updateListing, deleteListing, addCareLog, respondToQuery, submitQuery,
  addReview, deleteReview, removeUserProfile, platformStats,
  listNotifications, markRead, markAllRead, subscribeToNotifications, supabase
};
