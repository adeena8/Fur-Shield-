import { supabase } from "../lib/supabaseClient";

/**
 * All of these rely on the `profiles_admin_all` / `*_admin_all` RLS policies —
 * they will silently return nothing (or error) if called by a non-admin user.
 */

export async function listAllUsers() {
  const { data, error } = await supabase.from("profiles").select("*").order("created_at", { ascending: false });
  if (error) throw error;
  return data;
}

/**
 * Deletes a user's profile row (and, via ON DELETE CASCADE, their pets/orders/etc.).
 * NOTE: this does NOT delete the underlying auth.users row — the anon/public
 * client can never do that (Supabase requires the service_role key for
 * admin.deleteUser(), which must only ever run on a server, e.g. a Supabase
 * Edge Function). See README "Deleting a user's login" for the edge function
 * snippet. For most admin-panel needs, deleting the profile row is enough —
 * it immediately revokes the user's access to their own data everywhere.
 */
export async function removeUserProfile(userId) {
  const { error } = await supabase.from("profiles").delete().eq("id", userId);
  if (error) throw error;
}

export async function platformStats() {
  const [{ count: users }, { count: pets }, { count: appts }, { count: orders }, { count: listings }] = await Promise.all([
    supabase.from("profiles").select("*", { count: "exact", head: true }),
    supabase.from("pets").select("*", { count: "exact", head: true }),
    supabase.from("appointments").select("*", { count: "exact", head: true }),
    supabase.from("orders").select("*", { count: "exact", head: true }),
    supabase.from("shelter_listings").select("*", { count: "exact", head: true }),
  ]);
  return { users, pets, appts, orders, listings };
}
