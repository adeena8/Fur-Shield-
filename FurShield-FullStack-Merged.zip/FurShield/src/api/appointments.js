import { supabase } from "../lib/supabaseClient";

const cols = "id, pet_id, owner_id, vet_id, date, time, status, reason, created_at";

export async function listByOwner(ownerId) {
  const { data, error } = await supabase.from("appointments").select(cols).eq("owner_id", ownerId).order("date");
  if (error) throw error;
  return data;
}

export async function listByVet(vetId) {
  const { data, error } = await supabase.from("appointments").select(cols).eq("vet_id", vetId).order("date");
  if (error) throw error;
  return data;
}

// admin only (RLS enforces this)
export async function listAll() {
  const { data, error } = await supabase.from("appointments").select(cols).order("date");
  if (error) throw error;
  return data;
}

export async function createAppointment(appt) {
  // appt: { pet_id, owner_id, vet_id, date, time, reason }
  const { data, error } = await supabase.from("appointments").insert(appt).select(cols).single();
  if (error) throw error;
  return data;
}

export async function updateStatus(id, status) {
  const { data, error } = await supabase.from("appointments").update({ status }).eq("id", id).select(cols).single();
  if (error) throw error;
  return data;
}

export async function deleteAppointment(id) {
  const { error } = await supabase.from("appointments").delete().eq("id", id);
  if (error) throw error;
}
