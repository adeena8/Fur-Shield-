import { supabase } from "../lib/supabaseClient";

/**
 * Fetch the profiles row for a given auth user id.
 */
export async function getProfile(userId) {
  const { data, error } = await supabase
    .from("profiles")
    .select("*")
    .eq("id", userId)
    .single();
  if (error) throw error;
  return data;
}

/**
 * Returns the currently logged-in user's profile, or null if signed out.
 * Use this on app load to restore a session (equivalent of the old `user` state).
 */
export async function getCurrentUser() {
  const { data: { session } } = await supabase.auth.getSession();
  if (!session) return null;
  return getProfile(session.user.id);
}

/**
 * Log in and verify the account actually has the role selected on the login
 * screen (mirrors the original demo's doLogin(email, password, role) contract).
 * Throws a friendly Error if credentials are wrong or the role doesn't match.
 */
export async function signIn(email, password, expectedRole) {
  const { data, error } = await supabase.auth.signInWithPassword({ email, password });
  if (error) throw new Error("Invalid email or password.");

  const profile = await getProfile(data.user.id);
  if (expectedRole && profile.role !== expectedRole) {
    await supabase.auth.signOut();
    throw new Error("Invalid credentials for this role.");
  }
  return profile;
}

/**
 * Register a new account. `payload` mirrors the original doRegister(data) shape:
 * { role, name, email, password, phone, address, specialization?, experience?, bio? }
 * The profiles row is created automatically by the on_auth_user_created trigger,
 * reading these fields out of the auth user_metadata.
 * Note: admin accounts cannot self-register (enforced in the UI already, and
 * can also be enforced with a check constraint / edge function if desired).
 */
export async function signUp({ role, name, email, password, phone, address, specialization, experience, bio }) {
  const { data, error } = await supabase.auth.signUp({
    email,
    password,
    options: {
      data: { role, name, phone, address, specialization, experience, bio },
    },
  });
  if (error) throw error;

  // If email confirmations are OFF in your Supabase Auth settings, the user
  // is already signed in at this point and we can return their profile.
  if (data.session) {
    return getProfile(data.user.id);
  }
  // If email confirmations are ON, there's no session yet — caller should
  // prompt the user to check their inbox.
  return null;
}

export async function signOut() {
  const { error } = await supabase.auth.signOut();
  if (error) throw error;
}

/**
 * Subscribe to auth state changes (sign in / sign out / token refresh).
 * Returns an unsubscribe function.
 */
export function onAuthStateChange(callback) {
  const { data: sub } = supabase.auth.onAuthStateChange(async (_event, session) => {
    if (!session) return callback(null);
    try {
      const profile = await getProfile(session.user.id);
      callback(profile);
    } catch {
      callback(null);
    }
  });
  return () => sub.subscription.unsubscribe();
}

export async function updateProfile(userId, patch) {
  const { data, error } = await supabase.from("profiles").update(patch).eq("id", userId).select("*").single();
  if (error) throw error;
  return data;
}
