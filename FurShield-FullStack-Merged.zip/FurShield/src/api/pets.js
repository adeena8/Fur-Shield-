import { supabase } from "../lib/supabaseClient";

const cols = "id, owner_id, name, species, breed, age, gender, notes, images, created_at";

export async function listMyPets(ownerId) {
  const { data, error } = await supabase.from("pets").select(cols).eq("owner_id", ownerId).order("created_at");
  if (error) throw error;
  return data;
}

// vets/admins: all pets (needed to resolve pet names on appointments/records)
export async function listAllPets() {
  const { data, error } = await supabase.from("pets").select(cols);
  if (error) throw error;
  return data;
}

export async function createPet(ownerId, pet) {
  const { data, error } = await supabase
    .from("pets")
    .insert({ owner_id: ownerId, ...pet })
    .select(cols)
    .single();
  if (error) throw error;
  return data;
}

export async function updatePet(id, patch) {
  const { data, error } = await supabase.from("pets").update(patch).eq("id", id).select(cols).single();
  if (error) throw error;
  return data;
}

export async function deletePet(id) {
  const { error } = await supabase.from("pets").delete().eq("id", id);
  if (error) throw error;
}
