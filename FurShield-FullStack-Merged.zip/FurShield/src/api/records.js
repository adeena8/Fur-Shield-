import { supabase } from "../lib/supabaseClient";

const cols = "id, pet_id, vet_id, type, title, date, notes, created_at";

export async function listRecordsForPets(petIds) {
  if (!petIds?.length) return [];
  const { data, error } = await supabase.from("health_records").select(cols).in("pet_id", petIds).order("date", { ascending: false });
  if (error) throw error;
  return data;
}

export async function createRecord(record) {
  // record: { pet_id, vet_id, type, title, date, notes }
  const { data, error } = await supabase.from("health_records").insert(record).select(cols).single();
  if (error) throw error;
  return data;
}

export async function deleteRecord(id) {
  const { error } = await supabase.from("health_records").delete().eq("id", id);
  if (error) throw error;
}
