import { supabase } from "../lib/supabaseClient";

/* ---------------- Reviews ---------------- */
export async function listReviews() {
  const { data, error } = await supabase.from("reviews").select("*").order("created_at", { ascending: false });
  if (error) throw error;
  return data;
}

export async function addReview({ authorId, target, rating, comment, author }) {
  const { data, error } = await supabase
    .from("reviews")
    .insert({ author_id: authorId, target, rating, comment, author })
    .select()
    .single();
  if (error) throw error;
  return data;
}

export async function deleteReview(id) {
  const { error } = await supabase.from("reviews").delete().eq("id", id);
  if (error) throw error;
}

/* ---------------- Notifications ---------------- */
export async function listNotifications(userId) {
  const { data, error } = await supabase
    .from("notifications")
    .select("*")
    .eq("user_id", userId)
    .order("created_at", { ascending: false })
    .limit(30);
  if (error) throw error;
  return data;
}

export async function pushNotification(userId, { title, message, type = "system" }) {
  const { error } = await supabase.from("notifications").insert({ user_id: userId, title, message, type });
  if (error) throw error;
}

export async function markRead(id) {
  const { error } = await supabase.from("notifications").update({ read: true }).eq("id", id);
  if (error) throw error;
}

export async function markAllRead(userId) {
  const { error } = await supabase.from("notifications").update({ read: true }).eq("user_id", userId).eq("read", false);
  if (error) throw error;
}

/**
 * Live subscription: fires `onInsert` whenever a new notification lands for this user.
 * Returns an unsubscribe function. Requires Realtime enabled on the table (default on).
 */
export function subscribeToNotifications(userId, onInsert) {
  const channel = supabase
    .channel(`notifications:${userId}`)
    .on(
      "postgres_changes",
      { event: "INSERT", schema: "public", table: "notifications", filter: `user_id=eq.${userId}` },
      (payload) => onInsert(payload.new)
    )
    .subscribe();
  return () => supabase.removeChannel(channel);
}
