import { supabase } from "../lib/supabaseClient";

/* ---------------- Listings ---------------- */
export async function listAllListings() {
  const { data, error } = await supabase.from("shelter_listings").select("*").order("created_at", { ascending: false });
  if (error) throw error;
  return data;
}

export async function listMyListings(shelterId) {
  const { data, error } = await supabase.from("shelter_listings").select("*").eq("shelter_id", shelterId);
  if (error) throw error;
  return data;
}

export async function createListing(shelterId, listing) {
  const { data, error } = await supabase
    .from("shelter_listings")
    .insert({ shelter_id: shelterId, ...listing })
    .select()
    .single();
  if (error) throw error;
  return data;
}

export async function updateListing(id, patch) {
  const { data, error } = await supabase.from("shelter_listings").update(patch).eq("id", id).select().single();
  if (error) throw error;
  return data;
}

export async function deleteListing(id) {
  const { error } = await supabase.from("shelter_listings").delete().eq("id", id);
  if (error) throw error;
}

/* ---------------- Care logs ---------------- */
export async function listCareLogs(listingId) {
  const { data, error } = await supabase
    .from("care_logs")
    .select("*")
    .eq("listing_id", listingId)
    .order("date", { ascending: false });
  if (error) throw error;
  return data;
}

export async function addCareLog(listingId, log) {
  // log: { type, note }
  const { data, error } = await supabase.from("care_logs").insert({ listing_id: listingId, ...log }).select().single();
  if (error) throw error;
  return data;
}

/* ---------------- Adopter queries ---------------- */
// Public — works for logged-out visitors on the Adopt page too.
export async function submitQuery(listingId, { name, email, message }) {
  const { error } = await supabase.from("adopter_queries").insert({ listing_id: listingId, name, email, message });
  if (error) throw error;
}

export async function listQueriesForListings(listingIds) {
  if (!listingIds?.length) return [];
  const { data, error } = await supabase
    .from("adopter_queries")
    .select("*")
    .in("listing_id", listingIds)
    .order("created_at", { ascending: false });
  if (error) throw error;
  return data;
}

// admin only (RLS enforces this via the profiles.role check in the policy)
export async function listAllQueries() {
  const { data, error } = await supabase.from("adopter_queries").select("*").order("created_at", { ascending: false });
  if (error) throw error;
  return data;
}

export async function respondToQuery(id) {
  const { error } = await supabase.from("adopter_queries").update({ status: "Responded" }).eq("id", id);
  if (error) throw error;
}
