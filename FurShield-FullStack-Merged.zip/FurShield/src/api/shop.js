import { supabase } from "../lib/supabaseClient";

/* ---------------- Products ---------------- */
export async function listProducts() {
  const { data, error } = await supabase.from("products").select("*").order("category");
  if (error) throw error;
  return data;
}

/* ---------------- Cart ---------------- */
export async function getCart(ownerId) {
  const { data, error } = await supabase
    .from("cart_items")
    .select("id, product_id, qty, products(*)")
    .eq("owner_id", ownerId);
  if (error) throw error;
  return data;
}

export async function addToCart(ownerId, productId) {
  // Upsert: if the row exists, bump qty by 1 via a read-then-write (simple & explicit).
  const { data: existing } = await supabase
    .from("cart_items")
    .select("id, qty")
    .eq("owner_id", ownerId)
    .eq("product_id", productId)
    .maybeSingle();

  if (existing) {
    const { error } = await supabase.from("cart_items").update({ qty: existing.qty + 1 }).eq("id", existing.id);
    if (error) throw error;
  } else {
    const { error } = await supabase.from("cart_items").insert({ owner_id: ownerId, product_id: productId, qty: 1 });
    if (error) throw error;
  }
}

export async function setCartQty(ownerId, productId, qty) {
  if (qty <= 0) return removeFromCart(ownerId, productId);
  const { error } = await supabase
    .from("cart_items")
    .update({ qty })
    .eq("owner_id", ownerId)
    .eq("product_id", productId);
  if (error) throw error;
}

export async function removeFromCart(ownerId, productId) {
  const { error } = await supabase.from("cart_items").delete().eq("owner_id", ownerId).eq("product_id", productId);
  if (error) throw error;
}

export async function clearCart(ownerId) {
  const { error } = await supabase.from("cart_items").delete().eq("owner_id", ownerId);
  if (error) throw error;
}

/* ---------------- Orders ---------------- */
export async function listMyOrders(ownerId) {
  const { data, error } = await supabase
    .from("orders")
    .select("id, total, status, created_at, order_items(id, product_id, qty, unit_price, products(*))")
    .eq("owner_id", ownerId)
    .order("created_at", { ascending: false });
  if (error) throw error;
  return data;
}

// admin only (RLS enforces this)
export async function listAllOrders() {
  const { data, error } = await supabase
    .from("orders")
    .select("id, owner_id, total, status, created_at, order_items(id, product_id, qty, unit_price, products(*))")
    .order("created_at", { ascending: false });
  if (error) throw error;
  return data;
}

/**
 * Places an order from the current cart contents, then clears the cart.
 * cartRows: [{ product_id, qty, products: { price } }]
 */
export async function checkout(ownerId, cartRows) {
  const total = cartRows.reduce((s, c) => s + c.products.price * c.qty, 0);

  const { data: order, error: orderErr } = await supabase
    .from("orders")
    .insert({ owner_id: ownerId, total, status: "Placed" })
    .select()
    .single();
  if (orderErr) throw orderErr;

  const items = cartRows.map(c => ({
    order_id: order.id,
    product_id: c.product_id,
    qty: c.qty,
    unit_price: c.products.price,
  }));
  const { error: itemsErr } = await supabase.from("order_items").insert(items);
  if (itemsErr) throw itemsErr;

  await clearCart(ownerId);
  return order;
}

export async function updateOrderStatus(id, status) {
  const { error } = await supabase.from("orders").update({ status }).eq("id", id);
  if (error) throw error;
}
