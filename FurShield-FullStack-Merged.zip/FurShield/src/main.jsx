import React from 'react';
import { createRoot } from 'react-dom/client';
import './index.css';
import FurShieldApp from './FurShield.jsx';

createRoot(document.getElementById('root')).render(
  <React.StrictMode><FurShieldApp /></React.StrictMode>
);
