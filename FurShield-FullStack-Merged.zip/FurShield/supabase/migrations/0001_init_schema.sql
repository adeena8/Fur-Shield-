-- ============================================================================
-- FURSHIELD — Supabase Backend Schema
-- Roles: owner | vet | shelter | admin
-- Run this whole file once in Supabase SQL editor (or via `supabase db push`).
-- ============================================================================

create extension if not exists "pgcrypto";

-- ----------------------------------------------------------------------------
-- ROLE ENUM
-- ----------------------------------------------------------------------------
do $$ begin
  create type user_role as enum ('owner', 'vet', 'shelter', 'admin');
exception when duplicate_object then null; end $$;

-- ----------------------------------------------------------------------------
-- PROFILES  (1:1 with auth.users)
-- ----------------------------------------------------------------------------
create table if not exists public.profiles (
  id              uuid primary key references auth.users(id) on delete cascade,
  role            user_role not null default 'owner',
  name            text not null,
  email           text not null,
  phone           text,
  address         text,
  specialization  text,          -- vet only
  experience      text,          -- vet only
  bio             text,          -- vet only
  slots           text[] default '{}', -- vet only, e.g. {"Mon 10:00 AM"}
  created_at      timestamptz not null default now()
);

alter table public.profiles enable row level security;

-- Anyone signed in can read basic profile info (needed to show vet/shelter/owner
-- names across dashboards, adoption pages, appointment lists, etc.)
create policy "profiles_select_authenticated" on public.profiles
  for select to authenticated using (true);

-- A user can update only their own profile row.
create policy "profiles_update_own" on public.profiles
  for update to authenticated using (auth.uid() = id);

-- Admin can update/delete any profile.
create policy "profiles_admin_all" on public.profiles
  for all to authenticated
  using (exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin'))
  with check (exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin'));

-- ----------------------------------------------------------------------------
-- AUTO-CREATE PROFILE ON SIGNUP
-- Reads role/name/phone/etc. from auth signUp() options.data metadata.
-- ----------------------------------------------------------------------------
create or replace function public.handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id, role, name, email, phone, address, specialization, experience, bio)
  values (
    new.id,
    coalesce((new.raw_user_meta_data->>'role')::user_role, 'owner'),
    coalesce(new.raw_user_meta_data->>'name', split_part(new.email, '@', 1)),
    new.email,
    new.raw_user_meta_data->>'phone',
    new.raw_user_meta_data->>'address',
    new.raw_user_meta_data->>'specialization',
    new.raw_user_meta_data->>'experience',
    new.raw_user_meta_data->>'bio'
  );
  return new;
end;
$$ language plpgsql security definer set search_path = public;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- ----------------------------------------------------------------------------
-- PETS
-- ----------------------------------------------------------------------------
create table if not exists public.pets (
  id          uuid primary key default gen_random_uuid(),
  owner_id    uuid not null references public.profiles(id) on delete cascade,
  name        text not null,
  species     text not null,
  breed       text,
  age         text,
  gender      text,
  notes       text,
  images      text[] default '{}',
  created_at  timestamptz not null default now()
);
alter table public.pets enable row level security;

create policy "pets_owner_all" on public.pets
  for all to authenticated using (auth.uid() = owner_id) with check (auth.uid() = owner_id);

create policy "pets_vet_shelter_select" on public.pets
  for select to authenticated using (
    exists (select 1 from public.profiles p where p.id = auth.uid() and p.role in ('vet','admin'))
  );

-- ----------------------------------------------------------------------------
-- HEALTH RECORDS
-- ----------------------------------------------------------------------------
create table if not exists public.health_records (
  id          uuid primary key default gen_random_uuid(),
  pet_id      uuid not null references public.pets(id) on delete cascade,
  vet_id      uuid references public.profiles(id) on delete set null,
  type        text not null,       -- Vaccination | Treatment | Allergy | Milestone ...
  title       text not null,
  date        date not null default current_date,
  notes       text,
  created_at  timestamptz not null default now()
);
alter table public.health_records enable row level security;

create policy "records_owner_select" on public.health_records
  for select to authenticated using (
    exists (select 1 from public.pets pt where pt.id = pet_id and pt.owner_id = auth.uid())
  );

create policy "records_vet_write" on public.health_records
  for all to authenticated using (
    exists (select 1 from public.profiles p where p.id = auth.uid() and p.role in ('vet','admin'))
  ) with check (
    exists (select 1 from public.profiles p where p.id = auth.uid() and p.role in ('vet','admin'))
  );

-- ----------------------------------------------------------------------------
-- APPOINTMENTS
-- ----------------------------------------------------------------------------
create table if not exists public.appointments (
  id          uuid primary key default gen_random_uuid(),
  pet_id      uuid not null references public.pets(id) on delete cascade,
  owner_id    uuid not null references public.profiles(id) on delete cascade,
  vet_id      uuid not null references public.profiles(id) on delete cascade,
  date        date not null,
  time        text not null,
  status      text not null default 'Pending', -- Pending | Confirmed | Completed | Cancelled
  reason      text,
  created_at  timestamptz not null default now()
);
alter table public.appointments enable row level security;

create policy "appts_owner_all" on public.appointments
  for all to authenticated using (auth.uid() = owner_id) with check (auth.uid() = owner_id);

create policy "appts_vet_select_update" on public.appointments
  for select to authenticated using (
    auth.uid() = vet_id or exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin')
  );

create policy "appts_vet_update" on public.appointments
  for update to authenticated using (
    auth.uid() = vet_id or exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin')
  );

create policy "appts_admin_delete" on public.appointments
  for delete to authenticated using (
    exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin')
  );

-- ----------------------------------------------------------------------------
-- PRODUCTS  (public shop catalog)
-- ----------------------------------------------------------------------------
create table if not exists public.products (
  id          uuid primary key default gen_random_uuid(),
  name        text not null,
  category    text not null,
  price       numeric(10,2) not null,
  stock       int not null default 0,
  description text,
  icon        text,
  image       text,
  created_at  timestamptz not null default now()
);
alter table public.products enable row level security;

create policy "products_public_read" on public.products
  for select to authenticated, anon using (true);

create policy "products_admin_write" on public.products
  for all to authenticated using (
    exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin')
  ) with check (
    exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin')
  );

-- ----------------------------------------------------------------------------
-- CART ITEMS
-- ----------------------------------------------------------------------------
create table if not exists public.cart_items (
  id          uuid primary key default gen_random_uuid(),
  owner_id    uuid not null references public.profiles(id) on delete cascade,
  product_id  uuid not null references public.products(id) on delete cascade,
  qty         int not null default 1,
  unique (owner_id, product_id)
);
alter table public.cart_items enable row level security;

create policy "cart_owner_all" on public.cart_items
  for all to authenticated using (auth.uid() = owner_id) with check (auth.uid() = owner_id);

-- ----------------------------------------------------------------------------
-- ORDERS + ORDER ITEMS
-- ----------------------------------------------------------------------------
create table if not exists public.orders (
  id          uuid primary key default gen_random_uuid(),
  owner_id    uuid not null references public.profiles(id) on delete cascade,
  total       numeric(10,2) not null default 0,
  status      text not null default 'Placed', -- Placed | Shipped | Delivered | Cancelled
  created_at  timestamptz not null default now()
);
alter table public.orders enable row level security;

create table if not exists public.order_items (
  id          uuid primary key default gen_random_uuid(),
  order_id    uuid not null references public.orders(id) on delete cascade,
  product_id  uuid references public.products(id) on delete set null,
  qty         int not null,
  unit_price  numeric(10,2) not null
);
alter table public.order_items enable row level security;

create policy "orders_owner_select_insert" on public.orders
  for select to authenticated using (auth.uid() = owner_id);
create policy "orders_owner_insert" on public.orders
  for insert to authenticated with check (auth.uid() = owner_id);
create policy "orders_admin_all" on public.orders
  for all to authenticated using (
    exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin')
  ) with check (
    exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin')
  );

create policy "order_items_owner_select" on public.order_items
  for select to authenticated using (
    exists (select 1 from public.orders o where o.id = order_id and o.owner_id = auth.uid())
  );
create policy "order_items_owner_insert" on public.order_items
  for insert to authenticated with check (
    exists (select 1 from public.orders o where o.id = order_id and o.owner_id = auth.uid())
  );
create policy "order_items_admin_all" on public.order_items
  for all to authenticated using (
    exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin')
  ) with check (
    exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin')
  );

-- ----------------------------------------------------------------------------
-- SHELTER LISTINGS (adoption) + CARE LOGS
-- ----------------------------------------------------------------------------
create table if not exists public.shelter_listings (
  id          uuid primary key default gen_random_uuid(),
  shelter_id  uuid not null references public.profiles(id) on delete cascade,
  pet_name    text not null,
  species     text not null,
  breed       text,
  age         text,
  health      text,
  status      text not null default 'Available', -- Available | Pending | Adopted
  image       text,
  created_at  timestamptz not null default now()
);
alter table public.shelter_listings enable row level security;

create policy "listings_public_read" on public.shelter_listings
  for select to authenticated, anon using (true);

create policy "listings_shelter_write" on public.shelter_listings
  for all to authenticated using (
    auth.uid() = shelter_id or exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin')
  ) with check (
    auth.uid() = shelter_id or exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin')
  );

create table if not exists public.care_logs (
  id          uuid primary key default gen_random_uuid(),
  listing_id  uuid not null references public.shelter_listings(id) on delete cascade,
  type        text not null,   -- Feeding | Grooming | Medical
  note        text not null,
  date        date not null default current_date
);
alter table public.care_logs enable row level security;

create policy "care_logs_shelter_all" on public.care_logs
  for all to authenticated using (
    exists (
      select 1 from public.shelter_listings l
      where l.id = listing_id and (l.shelter_id = auth.uid()
        or exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin'))
    )
  ) with check (
    exists (
      select 1 from public.shelter_listings l
      where l.id = listing_id and (l.shelter_id = auth.uid()
        or exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin'))
    )
  );

-- ----------------------------------------------------------------------------
-- ADOPTER QUERIES  (public "interested in adopting" form — allows anon insert)
-- ----------------------------------------------------------------------------
create table if not exists public.adopter_queries (
  id          uuid primary key default gen_random_uuid(),
  listing_id  uuid not null references public.shelter_listings(id) on delete cascade,
  name        text not null,
  email       text not null,
  message     text,
  status      text not null default 'New', -- New | Responded
  created_at  timestamptz not null default now()
);
alter table public.adopter_queries enable row level security;

-- Anyone (even logged-out visitors) can submit an adoption inquiry.
create policy "queries_public_insert" on public.adopter_queries
  for insert to authenticated, anon with check (true);

create policy "queries_shelter_select_update" on public.adopter_queries
  for select to authenticated using (
    exists (
      select 1 from public.shelter_listings l
      where l.id = listing_id and (l.shelter_id = auth.uid()
        or exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin'))
    )
  );
create policy "queries_shelter_update" on public.adopter_queries
  for update to authenticated using (
    exists (
      select 1 from public.shelter_listings l
      where l.id = listing_id and (l.shelter_id = auth.uid()
        or exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin'))
    )
  );

-- ----------------------------------------------------------------------------
-- REVIEWS
-- ----------------------------------------------------------------------------
create table if not exists public.reviews (
  id          uuid primary key default gen_random_uuid(),
  author_id   uuid references public.profiles(id) on delete set null,
  target      text not null,   -- vet or shelter display name
  rating      int not null check (rating between 1 and 5),
  comment     text,
  author      text not null,   -- display name snapshot
  created_at  timestamptz not null default now()
);
alter table public.reviews enable row level security;

create policy "reviews_public_read" on public.reviews
  for select to authenticated, anon using (true);

create policy "reviews_owner_insert" on public.reviews
  for insert to authenticated with check (auth.uid() = author_id);

create policy "reviews_admin_delete" on public.reviews
  for delete to authenticated using (
    auth.uid() = author_id or exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin')
  );

-- ----------------------------------------------------------------------------
-- NOTIFICATIONS
-- ----------------------------------------------------------------------------
create table if not exists public.notifications (
  id          uuid primary key default gen_random_uuid(),
  user_id     uuid not null references public.profiles(id) on delete cascade,
  title       text not null,
  message     text,
  type        text default 'system',
  read        boolean not null default false,
  created_at  timestamptz not null default now()
);
alter table public.notifications enable row level security;

create policy "notifications_owner_all" on public.notifications
  for all to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- ----------------------------------------------------------------------------
-- HELPFUL INDEXES
-- ----------------------------------------------------------------------------
create index if not exists idx_pets_owner on public.pets(owner_id);
create index if not exists idx_records_pet on public.health_records(pet_id);
create index if not exists idx_appts_owner on public.appointments(owner_id);
create index if not exists idx_appts_vet on public.appointments(vet_id);
create index if not exists idx_cart_owner on public.cart_items(owner_id);
create index if not exists idx_orders_owner on public.orders(owner_id);
create index if not exists idx_order_items_order on public.order_items(order_id);
create index if not exists idx_listings_shelter on public.shelter_listings(shelter_id);
create index if not exists idx_care_logs_listing on public.care_logs(listing_id);
create index if not exists idx_queries_listing on public.adopter_queries(listing_id);
create index if not exists idx_notifications_user on public.notifications(user_id);
