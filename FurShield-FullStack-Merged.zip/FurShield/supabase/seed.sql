-- ============================================================================
-- FURSHIELD — Seed data
-- Run AFTER 0001_init_schema.sql. Safe to re-run (checks for existing rows).
-- Note: demo user accounts (owner/vet/shelter/admin) are NOT created here —
-- auth.users must be created via Supabase Auth (see README "Creating demo
-- accounts"). Their profiles.role is set automatically by the signup trigger.
-- ============================================================================

insert into public.products (name, category, price, stock, description, icon, image)
select * from (values
  ('Grain-Free Chicken Kibble 3kg', 'Food', 24.99, 40, 'Premium grain-free formula for sensitive stomachs.', '🥘', 'https://images.pexels.com/photos/12928244/pexels-photo-12928244.jpeg?auto=compress&cs=tinysrgb&w=1200'),
  ('Salmon & Rice Wet Food (12-pack)', 'Food', 18.50, 60, 'Complete balanced nutrition, vet-recommended.', '🐟', 'https://images.pexels.com/photos/8434633/pexels-photo-8434633.jpeg?auto=compress&cs=tinysrgb&w=1200'),
  ('Deshedding Slicker Brush', 'Grooming', 9.99, 75, 'Reduces shedding by up to 90%.', '🪮', 'https://images.pexels.com/photos/8498859/pexels-photo-8498859.jpeg?auto=compress&cs=tinysrgb&w=1200'),
  ('Oatmeal Calming Shampoo', 'Grooming', 12.00, 30, 'Soothes sensitive, itchy skin.', '🧴', 'https://images.pexels.com/photos/19021958/pexels-photo-19021958.jpeg?auto=compress&cs=tinysrgb&w=1200'),
  ('Rope & Squeak Toy Bundle', 'Toys', 14.99, 50, 'Set of 3 durable chew + squeak toys.', '🧸', 'https://images.pexels.com/photos/5483371/pexels-photo-5483371.jpeg?auto=compress&cs=tinysrgb&w=1200'),
  ('Feather Wand Cat Teaser', 'Toys', 6.50, 90, 'Interactive play for indoor cats.', '🪶', 'https://images.pexels.com/photos/38151508/pexels-photo-38151508.jpeg?auto=compress&cs=tinysrgb&w=1200'),
  ('Joint Care Chewables (60ct)', 'Health', 21.00, 25, 'Glucosamine + chondroitin support.', '💊', 'https://images.pexels.com/photos/15508182/pexels-photo-15508182.jpeg?auto=compress&cs=tinysrgb&w=1200'),
  ('Digital Ear Thermometer', 'Health', 16.75, 20, 'Fast, accurate readings at home.', '🌡️', 'https://images.pexels.com/photos/5994867/pexels-photo-5994867.jpeg?auto=compress&cs=tinysrgb&w=1200'),
  ('Clicker Training Kit', 'Training', 8.99, 45, 'Beginner-friendly positive reinforcement kit.', '🔔', 'https://images.pexels.com/photos/18188788/pexels-photo-18188788.jpeg?auto=compress&cs=tinysrgb&w=1200'),
  ('Puppy Pads (50-pack)', 'Training', 15.25, 55, 'Super-absorbent, leak-proof pads.', '📦', 'https://images.pexels.com/photos/4432261/pexels-photo-4432261.jpeg?auto=compress&cs=tinysrgb&w=1200')
) as v(name, category, price, stock, description, icon, image)
where not exists (select 1 from public.products p where p.name = v.name);
